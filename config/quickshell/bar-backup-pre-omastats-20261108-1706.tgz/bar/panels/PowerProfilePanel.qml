import QtQuick
import "../modules"
import Quickshell
import Quickshell.Io
import Quickshell.Wayland

PanelWindow {
    id: profilePanel
    required property var root

    screen: root.activePopupScreen

    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "omarchy-power-profile"

    readonly property int barBottom: 35
    readonly property int gap: 8

    readonly property var profiles: [
        { key: "power-saver",  icon: "\uF06C",  label: "Power Saver" },
        { key: "balanced",     icon: "\uF24E", label: "Balanced" },
        { key: "performance",  icon: "\uF0E7", label: "Performance" },
    ]

    property real reveal: root.powerProfileVisible ? 1 : 0
    Behavior on reveal {
        NumberAnimation {
            duration: root.powerProfileVisible ? 160 : 120
            easing.type: root.powerProfileVisible ? Easing.OutCubic : Easing.InCubic
        }
    }
    visible: reveal > 0.001
    WlrLayershell.keyboardFocus: root.powerProfileVisible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    MouseArea {
        anchors.fill: parent
        onClicked: root.powerProfileVisible = false
    }

    Rectangle {
        id: card
        width: 220
        height: col.implicitHeight + 24
        radius: reveal > 0.001 ? root.pillRadius : 0
        color: root.bg
        border.color: root.pillBorder
        border.width: root.pillBorderW
        PillShadow { theme: root }

        x: Math.round(Math.max(6, Math.min(root.powerBarX - width / 2, parent.width - width - 6)))
        y: root.barPosition === "bottom" ? (parent.height - barBottom - gap - height) : (barBottom + gap)
        opacity: profilePanel.reveal
        focus: root.powerProfileVisible

        Keys.onPressed: function(event) {
            if (event.key === Qt.Key_Escape) {
                root.powerProfileVisible = false;
                event.accepted = true;
            }
        }

        MouseArea { anchors.fill: parent; onClicked: {} }

        Column {
            id: col
            anchors.fill: parent
            anchors.margins: 12
            spacing: 4

            // ── header ──
            Item {
                width: parent.width
                height: 24
                UiText {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Power Profile"
                    color: root.ink
                    font.family: root.mono
                    font.pixelSize: 13
                    font.letterSpacing: 2
                    font.weight: Font.Medium
                }
                UiText {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    text: "\u2715"
                    color: closeMa.containsMouse ? root.seal : root.sumi
                    font.pixelSize: 12
                    Behavior on color { ColorAnimation { duration: 120 } }
                    MouseArea {
                        id: closeMa
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.powerProfileVisible = false
                    }
                }
            }

            Rectangle { width: parent.width; height: 1; color: root.sep }

            // ── profile buttons ──
            Repeater {
                model: profilePanel.profiles

                delegate: Item {
                    required property var modelData
                    required property int index

                    width: parent.width
                    height: 32

                    property bool isActive: root.powerProfileCurrent === modelData.key

                    Rectangle {
                        anchors.fill: parent
                        radius: root.tileRadius
                        color: isActive ? root.fillActive
                               : ma.containsMouse ? root.fillHover : root.fillIdle
                        border.color: (ma.containsMouse || isActive) ? root.seal : root.sep
                        border.width: 1
                        Behavior on color { ColorAnimation { duration: 120 } }
                    }

                    Row {
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.left: parent.left; anchors.leftMargin: 8
                        anchors.right: parent.right; anchors.rightMargin: 8
                        spacing: 8

                        UiText {
                            text: modelData.icon
                            renderType: Text.QtRendering
                            color: (ma.containsMouse || isActive) ? root.seal : root.ink
                            font.family: root.mono
                            font.pixelSize: 14
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        UiText {
                            text: modelData.label
                            color: (ma.containsMouse || isActive) ? root.seal : root.ink
                            font.family: root.mono
                            font.pixelSize: 12
                            font.weight: isActive ? Font.Medium : Font.Normal
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }

                    MouseArea {
                        id: ma
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            setProfileProc.command = ["bash", "-c", "powerprofilesctl set " + modelData.key]
                            setProfileProc.running = false
                            setProfileProc.running = true
                            root.powerProfileCurrent = modelData.key
                            root.powerProfileVisible = false
                        }
                    }
                }
            }
        }
    }

    Process {
        id: setProfileProc
        command: ["bash", "-c", "powerprofilesctl set balanced"]
        running: false
    }
}
