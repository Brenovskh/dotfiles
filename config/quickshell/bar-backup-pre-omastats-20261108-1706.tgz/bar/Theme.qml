import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import Quickshell.Services.UPower
import "Palette.js" as Palette

Item {
    id: theme
    property var variantHost: null
    signal reactorTest(string kind, string arg)

    property string omarchyCurrentRoot: Quickshell.env("HOME") + "/.config/omarchy/current"
    property string omarchyInstallRoot: Quickshell.env("HOME") + "/.local/share/omarchy"
    property bool omarchyCurrentRootResolved: false
    readonly property string themeNamePath: omarchyCurrentRoot + "/theme.name"
    readonly property string colorsPath: omarchyCurrentRoot + "/theme/colors.toml"
    readonly property string currentBackgroundPath: omarchyCurrentRoot + "/background"
    readonly property string currentBackgroundsPath: omarchyCurrentRoot + "/theme/backgrounds"
    property string currentThemeName: ""
    readonly property string userBackgroundsPath: currentThemeName === ""
        ? ""
        : Quickshell.env("HOME") + "/.config/omarchy/backgrounds/" + currentThemeName
    readonly property var wallpaperSourcePaths: userBackgroundsPath === ""
        ? [currentBackgroundsPath]
        : [currentBackgroundsPath, userBackgroundsPath]

    function setCurrentThemeName(rawName) {
        var name = String(rawName || "").trim()
        if (name === "." || name === ".." || name.indexOf("/") >= 0 || name.indexOf("\\") >= 0)
            name = ""
        currentThemeName = name
    }

    function reloadCurrentThemeFiles() {
        if (!omarchyCurrentRootResolved) return
        themeReloadDebounce.restart()
    }

    property color paper:   "#181616"
    property color ink:     "#c5c9c5"
    property color sumi:    "#a6a69c"
    property color color01: "#c4746e"
    property color color02: "#8a9a73"
    property color color03: "#c8b36a"
    property color color04: "#658594"
    property color color05: "#957fb8"
    property color color06: "#7aa89f"
    property color color07: "#c8c093"
    readonly property color inkDeep: color07
    readonly property color indigo:  color04
    readonly property color sealRaw: color01
    readonly property color sumiHi:  Qt.rgba(sumi.r*0.45 + ink.r*0.55, sumi.g*0.45 + ink.g*0.55, sumi.b*0.45 + ink.b*0.55, 1.0)  // lifted section-header text
    property color green:   "#8a9a73"   // gate "OK" verdict
    property color accentHint: sealRaw    // filled by palette; default = same as red
    readonly property color foregroundSoft: Qt.rgba(
        ink.r * 0.88 + paper.r * 0.12,
        ink.g * 0.88 + paper.g * 0.12,
        ink.b * 0.88 + paper.b * 0.12,
        1.0)
    property string barColor: "color01"
    readonly property bool barColorIsAccent: barColor === "accent"
    // Compatibility alias for older local code/reviews that still use the
    // previous boolean name.
    readonly property bool useThemeAccent: barColorIsAccent

    function paletteColor(id) {
        if (id === "color02") return color02
        if (id === "color03") return color03
        if (id === "color04") return color04
        if (id === "color05") return color05
        if (id === "color06") return color06
        if (id === "color07") return color07
        if (id === "foreground") return foregroundSoft
        if (id === "accent") return accentHint
        return color01
    }
    function normalizedPaletteId(id) {
        if (id === "red" || id === "accent") return "color01"
        return paletteColorValid(id) ? id : "color01"
    }
    readonly property color seal: paletteColor(barColor)
    readonly property var barColorOptions: [
        "color01", "color02", "color03", "color04",
        "color05", "color06", "color07", "foreground"
    ]
    function paletteColorValid(id) {
        return id === "color01" || id === "color02" || id === "color03"
            || id === "color04" || id === "color05" || id === "color06"
            || id === "color07" || id === "foreground"
    }
    function barColorValid(id) {
        return paletteColorValid(id) || id === "red" || id === "accent"
    }
    function barColorLabel(id) {
        if (id === "color01" || id === "red" || id === "accent") return "Color 01"
        if (id === "color02") return "Color 02"
        if (id === "color03") return "Color 03"
        if (id === "color04") return "Color 04"
        if (id === "color05") return "Color 05"
        if (id === "color06") return "Color 06"
        if (id === "color07") return "Color 07"
        if (id === "foreground") return "Foreground"
        return "Color 01"
    }
    function _linearColorChannel(v) {
        return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
    }
    function _relativeLuminance(c) {
        return 0.2126 * _linearColorChannel(c.r)
             + 0.7152 * _linearColorChannel(c.g)
             + 0.0722 * _linearColorChannel(c.b)
    }
    function _contrastRatio(a, b) {
        var la = _relativeLuminance(a)
        var lb = _relativeLuminance(b)
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
    }
    function paletteContrastColor(id) {
        var fill = paletteColor(id)
        return _contrastRatio(fill, paper) >= _contrastRatio(fill, ink) ? paper : ink
    }

    readonly property string mono:  "JetBrainsMono Nerd Font"

    // ── transparency knobs (0.0 = fully transparent, 1.0 = opaque) ──
    property real barOpacity:  0.94   // große Insel / Split-Sektionen
    property real pillOpacity: 0.18   // einzelne Widget-Pillen (workspace, mem, cpu, …)

    readonly property color bg:     Qt.rgba(paper.r, paper.g, paper.b, barOpacity)
    // bar island/section bg ONLY (NOT the shared bg -> panels keep their opacity): Frost
    // lowers the island alpha; compositor blur appears automatically when the theme
    // already blurs Quickshell layer surfaces.
    readonly property color barBg:  Qt.rgba(paper.r, paper.g, paper.b,
                                            styleFrost ? Math.min(barOpacity, 0.68) : barOpacity)
    readonly property color pill:   slantLayout ? "transparent" : Qt.rgba(paper.r, paper.g, paper.b, pillOpacity)
    // slanted-block layout (port of avnibilgin/dotfiles waybar): the bar sits flush
    // on the screen edge, every split section is a "/"-edged parallelogram with
    // alternating 60%/40% fill, the center (clock) section has no fill, and the
    // per-widget inner pills are hidden. false → original rounded-island look.
    property bool slantLayout: true
    readonly property int slantSkew: 16                  // horizontal run of each diagonal edge
    // original alternating 60%/40% fill; a thin ink outline marks each block's edges
    readonly property color slantBlockA: Qt.rgba(paper.r, paper.g, paper.b, 0.6)
    readonly property color slantBlockB: Qt.rgba(paper.r, paper.g, paper.b, 0.4)
    readonly property color slantBorder: Qt.rgba(ink.r, ink.g, ink.b, 0.35)
    readonly property real slantBorderW: 1
    readonly property color barPillBorder: slantLayout ? "transparent" : pillBorder
    readonly property color fg:     ink
    readonly property color muted:  sumi
    readonly property color accent: seal
    readonly property color warn:   seal
    readonly property color sep:    Qt.rgba(ink.r, ink.g, ink.b, 0.18)

    // ── interactive fill tokens (button/tile backgrounds) ──
    // One source of truth so every panel uses the same hover/active/idle alpha
    // instead of ad-hoc rgba literals scattered across the panels.
    readonly property real  fillActiveAlpha: 0.18
    readonly property real  fillHoverAlpha:  0.10
    readonly property color fillActive:      Qt.rgba(seal.r, seal.g, seal.b, fillActiveAlpha) // selected/active OR ghost-action hover
    readonly property color fillHover:        Qt.rgba(seal.r, seal.g, seal.b, fillHoverAlpha)  // light-seal hover (idle chip → this → fillActive)
    readonly property color fillIdle:         Qt.rgba(0, 0, 0, 0.12)              // resting chip (slight darken)
    // faint, NEUTRAL backdrop behind picker thumbnails — NOT an interactive fill.
    // ink-tinted and much weaker than fillIdle so a thumbnail sits on a quiet frame,
    // not on a dark interactive-looking box.
    readonly property color frameWeak:        Qt.rgba(ink.r, ink.g, ink.b, 0.05)
    readonly property color fillPrimaryHover: Qt.lighter(seal, 1.15)                // solid-seal button hover
    function evenW(w) { return 2 * Math.round(w / 2) }  // even px width -> integer-centered native text (crisp)

    // ── Multi-monitor popup routing ─────────────────────────────
    // Bars exist per screen, but panels remain singletons. The bar under the
    // pointer publishes its screen + local anchor map before any widget opens a
    // popup, so the singleton panel can move to the correct output.
    property var activePopupScreen: null
    property string activePopupScreenName: ""
    property var barAnchorsByScreen: ({})
    property bool _closingPopups: false
    property var barLayoutControllers: ({})
    property bool _barLayoutSyncing: false

    readonly property bool anyPopupVisible: calendarVisible || cpuVisible || aiUsageVisible
        || memVisible || volVisible || controlVisible || networkVisible || bluetoothVisible
        || batteryVisible || brightnessVisible || mprisVisible || weatherVisible
        || workspaceVisible || imagePickerVisible || mediaBrowserVisible || notifVisible
        || powerProfileVisible || archVisible || trayVisible || trayMenuVisible || systemStatsVisible
        || btcPriceVisible
    readonly property bool keyboardPopupVisible: imagePickerVisible || mediaBrowserVisible

    function registerBarLayoutController(screenName, controller) {
        if (!screenName || !controller) return

        var next = {}
        for (var screen in barLayoutControllers) next[screen] = barLayoutControllers[screen]
        next[screenName] = controller
        barLayoutControllers = next
    }

    function unregisterBarLayoutController(screenName, controller) {
        if (!screenName) return
        if (controller && barLayoutControllers[screenName] !== controller) return

        var next = {}
        for (var screen in barLayoutControllers) {
            if (screen !== screenName) next[screen] = barLayoutControllers[screen]
        }
        barLayoutControllers = next
    }

    function barLayoutControllerScreenValid(screenName) {
        if (!screenName) return false

        for (var i = 0; i < Quickshell.screens.length; i++) {
            var screen = Quickshell.screens[i]
            if (screen.name === screenName && screen.width > 0 && screen.height > 0) return true
        }
        return false
    }

    function barLayoutControllerKeys() {
        var keys = []
        for (var screen in barLayoutControllers) {
            if (barLayoutControllerScreenValid(screen)) keys.push(screen)
        }
        keys.sort()
        return keys
    }

    function applyToBarLayoutControllers(actionName) {
        var keys = barLayoutControllerKeys()

        _barLayoutSyncing = true
        try {
            for (var i = 0; i < keys.length; i++) {
                var controller = barLayoutControllers[keys[i]]
                if (controller && controller[actionName]) controller[actionName]()
            }
        } finally {
            _barLayoutSyncing = false
        }
    }

    function syncBarSplits(sourceScreenName, serialized) {
        if (_barLayoutSyncing || !serialized) return

        _barLayoutSyncing = true
        try {
            var keys = barLayoutControllerKeys()
            for (var i = 0; i < keys.length; i++) {
                if (keys[i] === sourceScreenName) continue
                var controller = barLayoutControllers[keys[i]]
                if (controller && controller.applySplits) controller.applySplits(serialized)
            }
        } finally {
            _barLayoutSyncing = false
        }
    }

    function syncBarOrder(sourceScreenName, serialized) {
        if (_barLayoutSyncing || !serialized) return

        _barLayoutSyncing = true
        try {
            var keys = barLayoutControllerKeys()
            for (var i = 0; i < keys.length; i++) {
                if (keys[i] === sourceScreenName) continue
                var controller = barLayoutControllers[keys[i]]
                if (controller && controller.applyOrder) controller.applyOrder(serialized)
            }
        } finally {
            _barLayoutSyncing = false
        }
    }

    function splitAllBars() {
        applyToBarLayoutControllers("splitAll")
    }

    function mergeAllBars() {
        applyToBarLayoutControllers("mergeAll")
    }

    function resetAllBarLayouts() {
        applyToBarLayoutControllers("defaultLayout")
        resetCompactDisplayModes()
    }

    function resetCompactDisplayModes() {
        var changed = compactNetwork || compactBattery || compactBrightness || compactCpu
                   || compactMemory || compactVolume || compactBluetooth || compactPower
                   || compactMpris
        _compactResetting = true
        compactNetwork = false
        compactBattery = false
        compactBrightness = false
        compactCpu = false
        compactMemory = false
        compactVolume = false
        compactBluetooth = false
        compactPower = false
        compactMpris = false
        _compactResetting = false
        if (changed && _widgetsLoaded) saveWidgets()
    }

    function activatePopupScreen(screen) {
        if (!screen || screen.name === "") return

        activePopupScreen = screen
        activePopupScreenName = screen.name
        applyActiveBarAnchors()
    }

    function activateFocusedPopupScreen() {
        var monitor = Hyprland.focusedMonitor
        var targetName = monitor ? monitor.name : ""

        for (var i = 0; i < Quickshell.screens.length; i++) {
            var candidate = Quickshell.screens[i]
            if (candidate.name === targetName
                    && candidate.width > 0
                    && candidate.height > 0) {
                activatePopupScreen(candidate)
                return true
            }
        }

        if (activePopupScreenName !== "") return true

        for (var j = 0; j < Quickshell.screens.length; j++) {
            var fallback = Quickshell.screens[j]
            if (fallback.name !== ""
                    && fallback.width > 0
                    && fallback.height > 0) {
                activatePopupScreen(fallback)
                return true
            }
        }

        return false
    }

    function activatePopupScreenByName(screenName) {
        if (screenName) {
            for (var i = 0; i < Quickshell.screens.length; i++) {
                var candidate = Quickshell.screens[i]
                if (candidate.name === screenName
                        && candidate.width > 0
                        && candidate.height > 0) {
                    activatePopupScreen(candidate)
                    return true
                }
            }
        }

        return activateFocusedPopupScreen()
    }

    Connections {
        target: Hyprland

        function onFocusedMonitorChanged() {
            if (!theme.keyboardPopupVisible || theme.activePopupScreenName === "") return

            var monitor = Hyprland.focusedMonitor
            var focusedName = monitor ? monitor.name : ""
            if (focusedName !== "" && focusedName !== theme.activePopupScreenName) {
                theme.closePopups()
            }
        }
    }

    function isActivePopupScreenName(screenName) {
        return activePopupScreenName !== "" && screenName === activePopupScreenName
    }

    function applyAnchor(name, x) {
        if (name === "tray") trayBarX = x
        else if (name === "notif") notifBarX = x
        else if (name === "quickActions") quickActionsBarX = x
        else if (name === "volume") volumeBarX = x
        else if (name === "network") networkBarX = x
        else if (name === "battery") batteryBarX = x
        else if (name === "memory") memoryBarX = x
        else if (name === "cpu") cpuBarX = x
        else if (name === "systemStats") systemStatsBarX = x
        else if (name === "ai") aiBarX = x
        else if (name === "workspace") workspaceBarX = x
        else if (name === "arch") archBarX = x
        else if (name === "bluetooth") bluetoothBarX = x
        else if (name === "brightness") brightnessBarX = x
        else if (name === "power") powerBarX = x
        else if (name === "mpris") mprisBarX = x
        else if (name === "weather") weatherBarX = x
        else if (name === "btcPrice") btcPriceBarX = x
        else if (name === "launcher") launcherBarX = x
        else if (name === "trayMenu") trayMenuX = x
    }

    function applyActiveBarAnchors() {
        var anchors = activePopupScreenName ? barAnchorsByScreen[activePopupScreenName] : null
        if (!anchors) return

        for (var name in anchors) applyAnchor(name, anchors[name])
    }

    function publishBarAnchors(screenName, anchors) {
        if (!screenName || !anchors) return

        var next = {}
        for (var screen in barAnchorsByScreen) next[screen] = barAnchorsByScreen[screen]
        next[screenName] = anchors
        barAnchorsByScreen = next

        if (screenName === activePopupScreenName) applyActiveBarAnchors()
    }

    function setPanelAnchor(name, x, screenName) {
        var targetScreen = screenName || activePopupScreenName
        if (targetScreen) {
            var next = {}
            for (var screen in barAnchorsByScreen) next[screen] = barAnchorsByScreen[screen]

            var current = next[targetScreen] || {}
            var anchors = {}
            for (var key in current) anchors[key] = current[key]
            anchors[name] = x
            next[targetScreen] = anchors
            barAnchorsByScreen = next
        }

        if (!targetScreen || targetScreen === activePopupScreenName) applyAnchor(name, x)
    }

    function closePopups(except) {
        _closingPopups = true
        if (except !== "calendarVisible") calendarVisible = false
        if (except !== "cpuVisible") cpuVisible = false
        if (except !== "aiUsageVisible") aiUsageVisible = false
        if (except !== "memVisible") memVisible = false
        if (except !== "volVisible") volVisible = false
        if (except !== "controlVisible") controlVisible = false
        if (except !== "networkVisible") networkVisible = false
        if (except !== "bluetoothVisible") bluetoothVisible = false
        if (except !== "batteryVisible") batteryVisible = false
        if (except !== "brightnessVisible") brightnessVisible = false
        if (except !== "mprisVisible") mprisVisible = false
        if (except !== "weatherVisible") weatherVisible = false
        if (except !== "workspaceVisible") workspaceVisible = false
        if (except !== "imagePickerVisible") imagePickerVisible = false
        if (except !== "mediaBrowserVisible") mediaBrowserVisible = false
        if (except !== "notifVisible") notifVisible = false
        if (except !== "powerProfileVisible") powerProfileVisible = false
        if (except !== "archVisible") archVisible = false
        if (except !== "trayVisible") trayVisible = false
        if (except !== "trayMenuVisible") trayMenuVisible = false
        if (except !== "worldClockVisible") worldClockVisible = false
        if (except !== "btcPriceVisible") btcPriceVisible = false
        hideTooltip()
        _closingPopups = false
    }

    function popupOpened(prop) {
        if (!_closingPopups && theme[prop]) closePopups(prop)
    }

    function openImagePicker(mode, screen) {
        if (imagePickerVisible && imagePickerMode !== mode)
            imagePickerVisible = false
        if (screen && screen.name !== "") activatePopupScreen(screen)
        else activateFocusedPopupScreen()
        mediaBrowserVisible = false
        imagePickerMode = mode
        imagePickerVisible = true
    }

    function toggleImagePicker(mode, screen) {
        if (imagePickerVisible && imagePickerMode === mode) {
            imagePickerVisible = false
            return
        }

        openImagePicker(mode, screen)
    }

    function openMediaBrowser(mode) {
        activateFocusedPopupScreen()
        imagePickerVisible = false
        mediaBrowserMode = mode
        mediaBrowserVisible = true
    }

    // ── pill/card border (default, non-borderless mode) ──
    // A premium "inactive window border" look: the surface tone (paper) nudged a
    // tick toward the foreground (ink) → a quiet edge a touch brighter than the
    // background, theme-aware in BOTH dark and light palettes. Tune via pillBorderMix.
    property real pillBorderMix: 0.13
    readonly property color pillBorder: Qt.rgba(
        paper.r * (1 - pillBorderMix) + ink.r * pillBorderMix,
        paper.g * (1 - pillBorderMix) + ink.g * pillBorderMix,
        paper.b * (1 - pillBorderMix) + ink.b * pillBorderMix, 1.0)
    // outer frame (the island edge against the wallpaper): a tick brighter than
    // the inner pill border so the bar lifts off the background → two readable
    // borders (subtle inner pills + a defined outer frame).
    property real islandBorderMix: 0.16
    readonly property color islandBorder: Qt.rgba(
        paper.r * (1 - islandBorderMix) + ink.r * islandBorderMix,
        paper.g * (1 - islandBorderMix) + ink.g * islandBorderMix,
        paper.b * (1 - islandBorderMix) + ink.b * islandBorderMix, 1.0)

    // ── bar style tokens (persisted; consumed by every pill/card surface) ──
    // Single source for the pill recipe; consumed by 37 surfaces (12 widgets +
    // 3 group pills + island + 20 cards + tooltip) — change the recipe here once.
    // border on/off and shadow on/off are INDEPENDENT (4 combos possible).
    property bool styleBorder:      true    // pill/card 1px border on/off
    property bool styleShadow:      false   // box-shadow on/off
    property bool styleFrost:       false   // lower bar-island opacity; theme blur may show through
    property bool styleRadiusSmall: false   // radius 12 ⇄ 6
    property bool styleHeightMin:   false   // inner pill 24 ⇄ 20 (slot stays 28)
    readonly property int   pillRadius:   styleRadiusSmall ? 6 : 12
    readonly property int   pillH:        styleHeightMin ? 20 : 24
    readonly property int   pillBorderW:  styleBorder ? 1 : 0
    readonly property int   islandRadius: styleRadiusSmall ? 8 : 16
    readonly property int   tileRadius:   pillRadius - 2   // inner panel buttons: 2 less than global (10 ⇄ 4)
    // horizontal padding of the workspace pill (overhang each side, mirrored by the
    // G2 slot pad). In "numbers" the wide digit badges should nestle concentrically
    // into the pill's inner radius → pad = pillRadius - badgeRadius; else a fixed 4.
    readonly property int   wsPillPad:    workspaceStyle === "numbers"
                                          ? Math.max(1, pillRadius - (styleRadiusSmall ? 5 : 10))
                                          : 4
    readonly property color pillShadow:   Qt.rgba(0, 0, 0, 0.55)   // dark, theme-independent

    property string lastAppliedName: ""

    // ── Tooltip state ──
    property string tooltipText: ""
    property real tooltipX: 0
    property real tooltipY: 0
    property real tooltipTopY: 0
    property real tooltipBottomY: 0
    property bool tooltipShown: false
    property var tooltipOwner: null   // the widget currently owning the tooltip

    function showTooltip(text, x, topY, bottomY, owner) {
        if (!text) return;
        tooltipText = text;
        tooltipX = x;
        tooltipTopY = topY;
        tooltipBottomY = bottomY;
        tooltipY = (topY + bottomY) / 2;
        tooltipOwner = owner !== undefined ? owner : null;
        tooltipShown = true;
    }

    // hide only if the caller owns the current tooltip (owner match is stable
    // even when the tooltip text changes, e.g. a live timer). A null/undefined
    // owner force-hides. Legacy string args fall back to a text match.
    function hideTooltip(owner) {
        if (owner === undefined || owner === null) {
            tooltipShown = false; tooltipOwner = null;
        } else if (typeof owner === "object") {
            if (tooltipOwner === owner) { tooltipShown = false; tooltipOwner = null; }
        } else if (tooltipText === owner) {
            tooltipShown = false; tooltipOwner = null;
        }
    }

    // safety net: if the owning widget disappears while its tooltip is shown
    // (e.g. ScreenRecord stops mid-hover, or a slot widget gets disabled), force-hide.
    // Via Connections — NOT a `_visible` property whose change-handler writes
    // tooltipOwner (that property read tooltipOwner → binding loop).
    Connections {
        target: theme.tooltipOwner
        ignoreUnknownSignals: true
        function onVisibleChanged() {
            if (theme.tooltipOwner && !theme.tooltipOwner.visible) {
                theme.tooltipShown = false; theme.tooltipOwner = null;
            }
        }
    }

    // ── Calendar state ──
    property bool calendarVisible: false
    onCalendarVisibleChanged: popupOpened("calendarVisible")
    property int calendarMonthOffset: 0
    property int calendarTick: 0
    property int selectedDay: 0
    // 1 = Monday, 0 = Sunday — mirrors Omarchy's clock-panel week-start toggle
    property int calendarWeekStart: 1

    function toggleCalendarWeekStart() {
        calendarWeekStart = calendarWeekStart === 1 ? 0 : 1;
    }

    readonly property var calendarWeekdayLabels: calendarWeekStart === 0
        ? ["ВС","ПН","ВТ","СР","ЧТ","ПТ","СБ"]
        : ["ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"]

    // ISO-8601 week number for the Thursday-anchored week containing `date`.
    function isoWeekNumber(date) {
        const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        const dayNum = (d.getUTCDay() + 6) % 7;
        d.setUTCDate(d.getUTCDate() - dayNum + 3);
        const firstThursday = new Date(Date.UTC(d.getUTCFullYear(), 0, 4));
        const diff = d - firstThursday;
        return 1 + Math.round(diff / (7 * 24 * 3600 * 1000));
    }

    readonly property var calendarCells: {
        calendarTick;
        calendarWeekStart;
        calendarEventDateSet;
        const f1days = f1DaySet;
        const now = new Date();
        const first = new Date(now.getFullYear(), now.getMonth() + calendarMonthOffset, 1);
        const year = first.getFullYear();
        const month = first.getMonth();
        const lastDay = new Date(year, month + 1, 0).getDate();
        const rawStartDay = (first.getDay() + 6) % 7; // 0=Mon .. 6=Sun
        const startDay = calendarWeekStart === 0 ? (rawStartDay + 1) % 7 : rawStartDay;
        const today = new Date();
        const isCurrentMonth = year === today.getFullYear() && month === today.getMonth();
        const cells = [];
        for (let i = 0; i < startDay; i++) cells.push({day: 0, today: false, date: null, dateKey: "", hasEvent: false, f1: false, f1Gp: false});
        for (let d = 1; d <= lastDay; d++) {
            const dk = calendarDateKey(year, month, d);
            const f1hit = f1days[dk];
            cells.push({
                day: d, today: isCurrentMonth && d === today.getDate(), date: new Date(year, month, d),
                dateKey: dk, hasEvent: !!calendarEventDateSet[dk],
                f1: !!f1hit, f1Gp: !!(f1hit && f1hit.isGp)
            });
        }
        while (cells.length < 42) cells.push({day: 0, today: false, date: null, dateKey: "", hasEvent: false, f1: false, f1Gp: false});
        return cells;
    }

    // One ISO week number per grid row (6 rows of 7 days each).
    readonly property var calendarWeekNumbers: {
        const cells = calendarCells;
        const weeks = [];
        for (let row = 0; row < 6; row++) {
            let anchor = null;
            for (let col = 0; col < 7; col++) {
                const cell = cells[row * 7 + col];
                if (cell.date !== null) { anchor = cell.date; break; }
            }
            weeks.push(anchor ? isoWeekNumber(anchor) : "");
        }
        return weeks;
    }

    readonly property string calendarMonthName: {
        const months = ["ЯНВАРЬ","ФЕВРАЛЬ","МАРТ","АПРЕЛЬ","МАЙ","ИЮНЬ",
                        "ИЮЛЬ","АВГУСТ","СЕНТЯБРЬ","ОКТЯБРЬ","НОЯБРЬ","ДЕКАБРЬ"];
        const now = new Date();
        return months[(now.getMonth() + calendarMonthOffset + 12000) % 12];
    }

    readonly property string calendarYear: {
        const now = new Date();
        const d = new Date(now.getFullYear(), now.getMonth() + calendarMonthOffset, 1);
        return String(d.getFullYear());
    }

    function openCalendar() {
        calendarMonthOffset = 0;
        calendarTick++;
        selectedDay = (new Date()).getDate();
        calendarSelectedDateKey = calendarTodayKey;
        calendarAddingEvent = false;
        calendarVisible = true;
    }

    // Toggle used by the bar's center clock/date group: close if open,
    // otherwise land the popup on the focused monitor and open it fresh at
    // the current month. Kept lighter than openCalendar() — no auto-select of
    // today — so the events section stays collapsed on open.
    function toggleCalendar() {
        if (calendarVisible) { calendarVisible = false; return; }
        if (activePopupScreenName === "") activateFocusedPopupScreen();
        calendarMonthOffset = 0;
        calendarTick++;
        calendarAddingEvent = false;
        calendarVisible = true;
    }

    // ── Calendar events + notifications ──
    // Feature and on-disk format ported from the "calendar-activity" Omarchy
    // plugin (github.com/archlatam/omarchy-calendar-activity), MIT License.
    // Same state file path as that plugin on purpose, so event data isn't
    // orphaned if the user ever tries the actual plugin.
    property var calendarEvents: []
    property bool calendarEventsLoaded: false
    property string calendarSelectedDateKey: ""
    property bool calendarAddingEvent: false
    property bool calendarNewEventNotify: false
    property string _calendarLastCheckedDay: ""

    function _cal2(n) { return (n < 10 ? "0" : "") + n; }
    function calendarDateKey(year, month, day) {
        return year + "-" + _cal2(month + 1) + "-" + _cal2(day);
    }
    function calendarDateKeyFromDate(d) {
        return calendarDateKey(d.getFullYear(), d.getMonth(), d.getDate());
    }
    readonly property string calendarTodayKey: calendarDateKeyFromDate(new Date())

    readonly property var calendarEventDateSet: {
        const set = {};
        for (let i = 0; i < calendarEvents.length; i++) set[calendarEvents[i].dateKey] = true;
        return set;
    }

    function calendarEventsForDay(dateKey) {
        const out = [];
        for (let i = 0; i < calendarEvents.length; i++)
            if (calendarEvents[i].dateKey === dateKey) out.push(calendarEvents[i]);
        out.sort(function(a, b) {
            if (a.time && b.time) return a.time < b.time ? -1 : (a.time > b.time ? 1 : 0);
            if (a.time) return -1;
            if (b.time) return 1;
            return 0;
        });
        return out;
    }

    function calendarNormalizeTime(t) {
        const s = String(t || "").trim();
        if (s === "") return "";
        const parts = s.split(":");
        if (parts.length < 2) return s;
        const h = parseInt(parts[0], 10), m = parseInt(parts[1], 10);
        if (isNaN(h) || isNaN(m)) return s;
        return _cal2(h) + ":" + _cal2(m);
    }

    function calendarSelectDay(dayNum, dateKey) {
        if (calendarSelectedDateKey === dateKey) {
            calendarSelectedDateKey = "";
            calendarAddingEvent = false;
            return;
        }
        selectedDay = dayNum;
        calendarSelectedDateKey = dateKey;
        calendarAddingEvent = false;
    }

    function calendarAddEvent(dateKey, title, time, notify) {
        const t = String(title || "").trim();
        if (t === "" || dateKey === "") return;
        const ev = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
            dateKey: dateKey,
            title: t,
            time: calendarNormalizeTime(time),
            notify: !!notify,
            notified: false,
            createdAt: Date.now()
        };
        calendarEvents = calendarEvents.concat([ev]);
        calendarSaveEvents();
    }

    function calendarDeleteEvent(id) {
        calendarEvents = calendarEvents.filter(function(e) { return e.id !== id; });
        calendarSaveEvents();
    }

    function calendarLoadEvents(raw) {
        if (calendarEventsLoaded) return;
        try {
            const parsed = JSON.parse(raw || "[]");
            calendarEvents = Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            calendarEvents = [];
        }
        calendarEventsLoaded = true;
    }

    function calendarSaveEvents() {
        calendarEventsFile.setText(JSON.stringify(calendarEvents, null, 2) + "\n");
    }

    function calendarTimeToMinutes(t) {
        if (!t) return -1;
        const parts = String(t).split(":");
        if (parts.length < 2) return -1;
        const h = parseInt(parts[0], 10), m = parseInt(parts[1], 10);
        if (isNaN(h) || isNaN(m)) return -1;
        return h * 60 + m;
    }

    function calendarCheckNotifications() {
        const todayKey = calendarTodayKey;
        if (_calendarLastCheckedDay !== "" && _calendarLastCheckedDay !== todayKey) {
            let resetAny = false;
            for (let i = 0; i < calendarEvents.length; i++) {
                if (calendarEvents[i].notified) { calendarEvents[i].notified = false; resetAny = true; }
            }
            if (resetAny) { calendarEvents = calendarEvents.slice(); calendarSaveEvents(); }
        }
        _calendarLastCheckedDay = todayKey;

        const now = new Date();
        const nowMinutes = now.getHours() * 60 + now.getMinutes();
        let changed = false;
        for (let i = 0; i < calendarEvents.length; i++) {
            const ev = calendarEvents[i];
            if (ev.dateKey !== todayKey || !ev.notify || ev.notified) continue;
            const evMinutes = calendarTimeToMinutes(ev.time);
            if (evMinutes < 0 || evMinutes > nowMinutes) continue;
            let body = ev.title;
            let sub = "Today";
            if (ev.time) sub += " at " + ev.time;
            calendarNotifyProc.command = ["notify-send", "-a", "Calendar", body, sub];
            calendarNotifyProc.running = false; calendarNotifyProc.running = true;
            ev.notified = true;
            changed = true;
        }
        if (changed) { calendarEvents = calendarEvents.slice(); calendarSaveEvents(); }
    }

    readonly property real calendarYearProgress: {
        const now = new Date();
        const start = new Date(now.getFullYear(), 0, 1);
        const totalDays = Math.round((new Date(now.getFullYear() + 1, 0, 1) - start) / 86400000);
        const dayOfYear = Math.round((now - start) / 86400000) + 1;
        return totalDays > 0 ? Math.max(0, Math.min(1, dayOfYear / totalDays)) : 0;
    }
    readonly property int calendarYearProgressPercent: Math.round(calendarYearProgress * 100)

    FileView {
        id: calendarEventsFile
        path: Quickshell.env("HOME") + "/.local/state/omarchy/year-calendar-events.json"
        atomicWrites: true
        watchChanges: false
        printErrors: false
        onLoaded: theme.calendarLoadEvents(text())
        onLoadFailed: theme.calendarLoadEvents("")
        Component.onCompleted: reload()
    }

    Process { id: calendarNotifyProc }

    Timer {
        interval: 10000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.calendarCheckNotifications()
    }

    // ── Formula 1 2026 calendar ──
    // Race-weekend days are highlighted in the calendar grid; clicking one
    // shows that Grand Prix's session schedule. Data is the f1calendar.com
    // dataset (github.com/sportstimes/f1, MIT) — per-session UTC timestamps,
    // which we convert to the machine's local time. Fetched weekly and cached
    // to disk so it also works offline; a seed copy is shipped at that path.
    readonly property string f1ApiUrl:
        "https://raw.githubusercontent.com/sportstimes/f1/main/_db/f1/2026.json"
    readonly property string f1StatePath:
        Quickshell.env("HOME") + "/.local/state/omarchy/f1-calendar-2026.json"
    readonly property color f1Accent: "#e10600"

    property var f1Races: []          // [{round, name, location, circuit, sprint, sessions, gpTs}]
    property int f1Retries: 0

    // slug -> circuit name; falls back to the race location when a slug is
    // missing here (e.g. calendar changes upstream). Kept small on purpose.
    readonly property var f1Circuits: ({
        "australian-grand-prix": "Albert Park Circuit",
        "chinese-grand-prix": "Shanghai International Circuit",
        "japanese-grand-prix": "Suzuka Circuit",
        "miami-grand-prix": "Miami International Autodrome",
        "canadian-grand-prix": "Circuit Gilles Villeneuve",
        "monaco-grand-prix": "Circuit de Monaco",
        "barcelona-catalunya-grand-prix": "Circuit de Barcelona-Catalunya",
        "austrian-grand-prix": "Red Bull Ring",
        "british-grand-prix": "Silverstone Circuit",
        "belgian-grand-prix": "Circuit de Spa-Francorchamps",
        "hungarian-grand-prix": "Hungaroring",
        "dutch-grand-prix": "Circuit Zandvoort",
        "italian-grand-prix": "Autodromo Nazionale Monza",
        "spanish-grand-prix": "Madring",
        "azerbaijan-grand-prix": "Baku City Circuit",
        "bahrain-malaysia-grand-prix": "Sepang International Circuit",
        "singapore-grand-prix": "Marina Bay Street Circuit",
        "us-grand-prix": "Circuit of the Americas",
        "mexican-grand-prix": "Autodromo Hermanos Rodriguez",
        "brazilian-grand-prix": "Interlagos",
        "las-vegas-grand-prix": "Las Vegas Strip Circuit",
        "qatar-grand-prix": "Lusail International Circuit",
        "abu-dhabi-grand-prix": "Yas Marina Circuit"
    })

    function f1CircuitFor(slug, fallback) {
        var c = f1Circuits[slug];
        return c ? c : (fallback || "");
    }

    // session key -> short label, in the order they run across a weekend
    readonly property var f1SessionOrder: ["fp1", "fp2", "fp3", "sprintQualifying", "sprint", "qualifying", "gp"]
    readonly property var f1SessionLabels: ({
        "fp1": "FP1", "fp2": "FP2", "fp3": "FP3",
        "sprintQualifying": "Sprint Quali", "sprint": "Sprint",
        "qualifying": "Qualifying", "gp": "Race"
    })

    function f1BuildRace(r) {
        var sessions = [];
        for (var i = 0; i < f1SessionOrder.length; i++) {
            var k = f1SessionOrder[i];
            var iso = (r.sessions && r.sessions[k]) ? r.sessions[k] : null;
            if (!iso) continue;
            var d = new Date(iso);
            if (isNaN(d.getTime())) continue;
            sessions.push({
                key: k,
                label: f1SessionLabels[k] || k,
                dateKey: calendarDateKeyFromDate(d),
                time: _cal2(d.getHours()) + ":" + _cal2(d.getMinutes()),
                ts: d.getTime()
            });
        }
        var nm = String(r.name || "");
        if (nm.indexOf("Grand Prix") < 0) nm = nm + " Grand Prix";
        var gp = null;
        for (var j = 0; j < sessions.length; j++) if (sessions[j].key === "gp") gp = sessions[j];
        return {
            round: r.round,
            name: nm,
            location: r.location || "",
            circuit: f1CircuitFor(r.slug, r.location),
            sprint: !!(r.sessions && r.sessions.sprint),
            sessions: sessions,
            gpDateKey: gp ? gp.dateKey : (sessions.length ? sessions[sessions.length - 1].dateKey : ""),
            gpTs: gp ? gp.ts : 0
        };
    }

    function f1IngestRaw(raw) {
        try {
            var parsed = JSON.parse(raw || "{}");
            var list = parsed && Array.isArray(parsed.races) ? parsed.races : [];
            var out = [];
            for (var i = 0; i < list.length; i++) out.push(f1BuildRace(list[i]));
            f1Races = out;
        } catch (e) {
            // keep whatever was loaded before
        }
    }

    // dateKey -> { raceIndex, isGp } for every day that has any F1 session
    readonly property var f1DaySet: {
        var set = {};
        for (var i = 0; i < f1Races.length; i++) {
            var r = f1Races[i];
            for (var j = 0; j < r.sessions.length; j++) {
                var s = r.sessions[j];
                if (!set[s.dateKey]) set[s.dateKey] = { raceIndex: i, isGp: false };
                if (s.key === "gp") set[s.dateKey].isGp = true;
            }
        }
        return set;
    }

    function f1ForDay(dateKey) {
        if (!dateKey) return null;
        var hit = f1DaySet[dateKey];
        if (!hit) return null;
        return f1Races[hit.raceIndex];
    }

    function f1Refresh(force) {
        if (f1FetchProc.running) {
            if (!force) return;
            f1FetchProc.running = false;
        }
        f1Retries = 0;
        f1FetchProc.running = true;
    }

    function f1ScheduleRetry() {
        if (f1Retries >= 3) return;
        f1Retries++;
        f1RetryTimer.restart();
    }

    FileView {
        id: f1CacheFile
        path: theme.f1StatePath
        atomicWrites: true
        watchChanges: false
        printErrors: false
        onLoaded: theme.f1IngestRaw(text())
        onLoadFailed: { /* no cache yet — the fetch below will populate it */ }
        Component.onCompleted: reload()
    }

    Process {
        id: f1FetchProc
        command: ["curl", "-fsS", "--max-time", "15", theme.f1ApiUrl]
        stdout: StdioCollector {
            waitForEnd: true
            onStreamFinished: {
                var raw = String(this.text || "").trim();
                if (!raw) { theme.f1ScheduleRetry(); return; }
                try {
                    var parsed = JSON.parse(raw);
                    if (!parsed || !Array.isArray(parsed.races) || parsed.races.length === 0) {
                        theme.f1ScheduleRetry(); return;
                    }
                    theme.f1IngestRaw(raw);
                    f1CacheFile.setText(raw);
                    theme.f1Retries = 0;
                } catch (e) {
                    theme.f1ScheduleRetry();
                }
            }
        }
        onExited: function(exitCode) {
            if (exitCode !== 0) theme.f1ScheduleRetry();
        }
    }

    Timer {
        id: f1RetryTimer
        interval: 10000
        onTriggered: if (!f1FetchProc.running) f1FetchProc.running = true
    }

    Timer {
        interval: 7 * 24 * 60 * 60 * 1000   // weekly; the calendar changes rarely
        running: true; repeat: true; triggeredOnStart: true
        onTriggered: theme.f1Refresh(false)
    }

    // ── World clock: pinned list of city times, feature ported from the
    // "io.github.olivoil.world-clock" Omarchy plugin
    // (github.com/olivoil/omarchy-world-clock, MIT) — that plugin is a
    // compiled Rust binary with its own native popup, so only the concept
    // (a pinned list of cities' current time + offset from local) and
    // general layout idea are ported here, reimplemented in QML/bash. ──
    property bool worldClockVisible: false
    onWorldClockVisibleChanged: popupOpened("worldClockVisible")

    readonly property var worldClockCities: [
        { name: "London",      tz: "Europe/London",       flag: "gb" },
        { name: "Paris",       tz: "Europe/Paris",        flag: "fr" },
        { name: "Cairo",       tz: "Africa/Cairo",        flag: "eg" },
        { name: "Moscow",      tz: "Europe/Moscow",       flag: "ru" },
        { name: "Dubai",       tz: "Asia/Dubai",          flag: "ae" },
        { name: "New Delhi",   tz: "Asia/Kolkata",        flag: "in" },
        { name: "Beijing",     tz: "Asia/Shanghai",       flag: "cn" },
        { name: "Tokyo",       tz: "Asia/Tokyo",          flag: "jp" },
        { name: "Canberra",    tz: "Australia/Canberra",  flag: "au" },
        { name: "Reykjavik",   tz: "Atlantic/Reykjavik",  flag: "is" },
        { name: "Los Angeles", tz: "America/Los_Angeles", flag: "us" },
        { name: "New York",    tz: "America/New_York",    flag: "us" }
    ]

    property var worldClockData: []   // [{time, dateKey, abbrev, dayDiff, diffMinutes}], same order as worldClockCities

    function _tzOffsetMinutes(s) {
        if (!s || s.length < 5) return 0;
        const sign = s.charAt(0) === "-" ? -1 : 1;
        const hh = parseInt(s.substr(1, 2), 10);
        const mm = parseInt(s.substr(3, 2), 10);
        return sign * (hh * 60 + (isNaN(mm) ? 0 : mm));
    }

    function worldClockRefresh() {
        var cmd = ["bash", "-c",
            'date "+LOCAL|%z"; for tz in "$@"; do TZ="$tz" date "+%H:%M|%Y-%m-%d|%Z|%z"; done', "--"]
        for (var i = 0; i < worldClockCities.length; i++) cmd.push(worldClockCities[i].tz)
        worldClockProc.command = cmd
        worldClockProc.running = false
        worldClockProc.running = true
    }

    Process {
        id: worldClockProc
        stdout: StdioCollector {
            onStreamFinished: {
                var lines = String(this.text || "").trim().split("\n")
                if (lines.length === 0) return
                var localParts = lines[0].split("|")
                var localOffset = theme._tzOffsetMinutes(localParts.length > 1 ? localParts[1] : "+0000")
                var localKey = Qt.formatDate(new Date(), "yyyy-MM-dd")
                var localMs = new Date(localKey + "T00:00:00").getTime()
                var out = []
                for (var i = 1; i < lines.length; i++) {
                    var parts = lines[i].split("|")
                    if (parts.length < 4) continue
                    var ms = new Date(parts[1] + "T00:00:00").getTime()
                    out.push({
                        time: parts[0],
                        dateKey: parts[1],
                        abbrev: parts[2],
                        dayDiff: Math.round((ms - localMs) / 86400000),
                        diffMinutes: theme._tzOffsetMinutes(parts[3]) - localOffset
                    })
                }
                theme.worldClockData = out
            }
        }
    }

    Timer {
        interval: 30000
        running: theme.worldClockVisible
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.worldClockRefresh()
    }

    // ── CPU panel state ──
    property bool cpuVisible: false
    onCpuVisibleChanged: popupOpened("cpuVisible")

    // ── combined System Stats panel state (CPU + GPU + Memory + Storage) ──
    property bool systemStatsVisible: false
    onSystemStatsVisibleChanged: popupOpened("systemStatsVisible")

    // ── BTC price panel state ──
    property bool btcPriceVisible: false
    onBtcPriceVisibleChanged: popupOpened("btcPriceVisible")

    // ── AI usage panel state + which tool the bar pill shows ──
    property bool   aiUsageVisible: false
    onAiUsageVisibleChanged: {
        popupOpened("aiUsageVisible")
        if (aiUsageVisible) refreshAiUsage()
    }
    property string aiTool: "claude"   // "claude", "codex", or "opencode" — icon shown in the bar

    // ── AI usage data (single source of truth) ───────────────────
    // The bar pill (ClaudeWidget) and the AiUsagePanel both render from these —
    // the cache parsing lives ONLY here so the two views can never drift apart.
    // Token strings are bare "X.XXM / Y.YM"; the pill tooltip appends " tokens".
    property bool   aiClHas: false
    property bool   aiClFresh: false
    property int    aiClPct5h: 0
    property int    aiClPct7d: 0
    property bool   aiClBlocked: false
    property string aiClTokens: ""
    property string aiClRate: ""
    property int    aiClReset5hTs: 0
    property int    aiClReset7dTs: 0
    property int    aiClToday: 0

    property bool   aiCxHas: false
    property bool   aiCxFresh: false
    property int    aiCxPct5h: 0
    property int    aiCxPct7d: 0
    property string aiCxPlan: ""
    property string aiCxTokens: ""
    property string aiCxRate: ""
    property int    aiCxReset5hTs: 0
    property int    aiCxReset7dTs: 0
    property int    aiCxToday: 0
    property var    aiCxBuckets: []
    property var    aiCxWindows: []
    property int    aiCxPrimaryPct: 0
    property string aiCxPrimaryLabel: ""
    property int    aiCxPrimaryResetTs: 0
    property int    aiCxQuotaPct: 0
    property string aiCxQuotaLabel: ""
    property string aiCxLimitStatus: ""
    property string aiCxLimitReachedType: ""

    property bool   aiOcHas: false
    property bool   aiOcFresh: false
    property int    aiOcPct5h: 0
    property int    aiOcPct7d: 0
    property string aiOcPlan: ""
    property string aiOcTokens: ""
    property string aiOcRate: ""
    property string aiOcModel: ""
    property int    aiOcToday: 0
    property var    aiOcModels: []
    property int    aiClockTick: 0

    // F15: clamp an external 0..1 utilization to a 0–100 int (a negative/over-range value would
    // otherwise produce wrong text and negative/overwide usage bars)
    function aiPct(v) { return Math.max(0, Math.min(100, Math.round((parseFloat(v) || 0) * 100))) }

    function aiWindowLabel(minutes) {
        if (minutes === 300) return "5h"
        if (minutes === 10080) return "Weekly"
        if (minutes > 0 && minutes % 1440 === 0) return (minutes / 1440) + "d"
        if (minutes > 0 && minutes % 60 === 0) return (minutes / 60) + "h"
        return minutes > 0 ? minutes + "m" : "window"
    }

    function aiResetCodexUsage() {
        aiCxHas = false; aiCxFresh = false
        aiCxPct5h = 0; aiCxPct7d = 0
        aiCxPlan = ""; aiCxTokens = ""; aiCxRate = ""; aiCxToday = 0
        aiCxReset5hTs = 0; aiCxReset7dTs = 0
        aiCxBuckets = []; aiCxWindows = []
        aiCxPrimaryPct = 0; aiCxPrimaryLabel = ""; aiCxPrimaryResetTs = 0
        aiCxQuotaPct = 0; aiCxQuotaLabel = ""
        aiCxLimitStatus = ""; aiCxLimitReachedType = ""
    }

    function aiCodexWindowFromCache(w) {
        w = w || {}
        var minutes = parseInt(w.minutes) || 0
        return {
            kind: String(w.kind || ""),
            minutes: minutes,
            label: String(w.label || theme.aiWindowLabel(minutes)),
            pct: theme.aiPct(w.utilization),
            resetTs: parseInt(w.reset) || 0
        }
    }

    function aiCodexWindowsFromArray(arr) {
        var out = []
        if (!arr || arr.length === undefined) return out
        for (var i = 0; i < arr.length; i++) {
            out.push(theme.aiCodexWindowFromCache(arr[i]))
        }
        return out
    }

    function aiCodexLegacyWindowsFromCache(d) {
        var out = []
        if (!d) return out
        var has5 = d["5h-utilization"] !== undefined && String(d["5h-utilization"]) !== ""
        var has7 = d["7d-utilization"] !== undefined && String(d["7d-utilization"]) !== ""
        if (has5 || parseInt(d["5h-reset"]) > 0)
            out.push({ kind: "primary", minutes: 300, label: "5h", pct: theme.aiPct(d["5h-utilization"]), resetTs: parseInt(d["5h-reset"]) || 0 })
        if (has7 || parseInt(d["7d-reset"]) > 0)
            out.push({ kind: "secondary", minutes: 10080, label: "Weekly", pct: theme.aiPct(d["7d-utilization"]), resetTs: parseInt(d["7d-reset"]) || 0 })
        return out
    }

    function aiCodexBucketsFromCache(d) {
        var buckets = []
        if (d && parseInt(d.schemaVersion) === 3 && d.buckets && d.buckets.length !== undefined) {
            for (var i = 0; i < d.buckets.length; i++) {
                var b = d.buckets[i] || {}
                var windows = theme.aiCodexWindowsFromArray(b.windows)
                if (windows.length === 0) continue
                buckets.push({
                    id: String(b.id || ""),
                    label: String(b.label || b.id || "Codex"),
                    isGeneral: b.isGeneral === true,
                    windows: windows,
                    plan: String(b.plan || ""),
                    rateLimitReachedType: String(b.rateLimitReachedType || "")
                })
            }
        } else if (d && parseInt(d.schemaVersion) === 2 && d.windows && d.windows.length !== undefined) {
            var win2 = theme.aiCodexWindowsFromArray(d.windows)
            if (win2.length > 0)
                buckets.push({ id: "codex", label: "Codex", isGeneral: true, windows: win2, plan: String(d._plan || "") })
        } else {
            var legacy = theme.aiCodexLegacyWindowsFromCache(d)
            if (legacy.length > 0)
                buckets.push({ id: "codex", label: "Codex", isGeneral: true, windows: legacy, plan: String((d && d._plan) || "") })
        }
        return buckets
    }

    function aiCodexGeneralBucket(buckets) {
        for (var i = 0; i < buckets.length; i++) {
            if (buckets[i].isGeneral === true || buckets[i].id === "codex") return buckets[i]
        }
        return { windows: [] }
    }

    function aiPlanLabel(plan) {
        var p = String(plan || "").toLowerCase()
        if (p === "prolite") return "Pro Lite"
        if (p === "pro") return "Pro"
        if (p === "plus") return "Plus"
        if (p === "team" || p === "business") return "Business"
        if (p === "enterprise") return "Enterprise"
        if (p === "edu") return "Edu"
        if (p === "free") return "Free"
        return String(plan || "")
    }

    function aiApplyCodexCache(d, ageOk) {
        var buckets = theme.aiCodexBucketsFromCache(d)
        var general = theme.aiCodexGeneralBucket(buckets)
        var windows = general.windows || []
        theme.aiCxHas = windows.length > 0
        theme.aiCxFresh = ageOk && d._source !== "stale"
        theme.aiCxBuckets = buckets
        theme.aiCxWindows = windows
        theme.aiCxPlan = theme.aiPlanLabel(d._plan || general.plan || "")
        theme.aiCxPct5h = 0; theme.aiCxPct7d = 0
        theme.aiCxReset5hTs = 0; theme.aiCxReset7dTs = 0
        theme.aiCxQuotaPct = 0
        theme.aiCxQuotaLabel = ""
        theme.aiCxLimitStatus = String(d.status || "")
        theme.aiCxLimitReachedType = String(d._limit_reached_type || general.rateLimitReachedType || "")
        for (var i = 0; i < windows.length; i++) {
            var w = windows[i]
            if (i === 0) {
                theme.aiCxPrimaryPct = w.pct
                theme.aiCxPrimaryLabel = w.label
                theme.aiCxPrimaryResetTs = w.resetTs
            }
            if (w.minutes === 300) { theme.aiCxPct5h = w.pct; theme.aiCxReset5hTs = w.resetTs }
            else if (w.minutes === 10080) { theme.aiCxPct7d = w.pct; theme.aiCxReset7dTs = w.resetTs }
            if (w.pct > theme.aiCxQuotaPct) {
                theme.aiCxQuotaPct = w.pct
                theme.aiCxQuotaLabel = String(general.label || "Codex") + " " + String(w.label || "window")
            }
        }
        if (windows.length === 0) {
            theme.aiCxPrimaryPct = 0
            theme.aiCxPrimaryLabel = ""
            theme.aiCxPrimaryResetTs = 0
        }
        var cxRateH = Math.round((d["_rate_per_hour"] || 0) / 1000)
        theme.aiCxRate = cxRateH > 0 ? cxRateH + "k tok/h" : ""
        theme.aiCxToday = parseInt(d._today_tokens) || 0
        theme.aiCxTokens = ""
    }

    function aiCodexStatusLabel(status, reachedType) {
        if (status === "rejected")
            return reachedType ? "reached (" + reachedType + ")" : "reached"
        if (status === "allowed_warning") return "warning"
        if (status === "allowed") return "ok (not reached)"
        return "unknown"
    }

    function aiFmtReset(ts) {
        aiClockTick
        var now = Date.now() / 1000
        if (!(ts > now)) return ""
        var mins = Math.round((ts - now) / 60)
        if (mins < 60) return mins + "m"
        var h = Math.floor(mins / 60), m = mins % 60
        if (h < 24) return h + "h " + m + "m"
        var d = Math.floor(h / 24); return d + "d " + (h % 24) + "h"
    }

    function aiPad2(n) { return n < 10 ? "0" + n : "" + n }

    function aiFmtResetClock(ts) {
        aiClockTick
        if (!(ts > Date.now() / 1000)) return ""
        var d = new Date(ts * 1000)
        var now = new Date()
        var day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()
        var resetDay0 = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
        var dayDelta = Math.round((resetDay0 - day0) / 86400000)
        var time = aiPad2(d.getHours()) + ":" + aiPad2(d.getMinutes())
        if (dayDelta <= 0) return time
        var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        return days[d.getDay()] + " " + time
    }

    function aiFmtResetDetail(ts) {
        var rel = aiFmtReset(ts)
        var clock = aiFmtResetClock(ts)
        return rel && clock ? rel + " • " + clock : (rel || clock)
    }

    Process {
        id: aiReadClaude
        command: ["bash", "-c",
            "f=\"$HOME/.cache/claude-usage.json\"; stat -c %Y \"$f\" 2>/dev/null; cat \"$f\" 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                var raw = this.text, nl = raw.indexOf("\n")
                var mtime = nl > 0 ? (parseInt(raw.substring(0, nl)) || 0) : 0
                var ageOk = mtime > 0 && (Date.now() / 1000 - mtime) < 900
                try {
                    var d = JSON.parse((nl > 0 ? raw.substring(nl + 1) : "").trim())
                    theme.aiClHas = true
                    theme.aiClFresh = ageOk && d._source !== "stale"
                    theme.aiClPct5h = theme.aiPct(d["5h-utilization"])
                    theme.aiClPct7d = theme.aiPct(d["7d-utilization"])
                    theme.aiClBlocked = d.status === "rejected" || d.status === "blocked"
                    theme.aiClReset5hTs = parseInt(d["5h-reset"]) || 0
                    theme.aiClReset7dTs = parseInt(d["7d-reset"]) || 0
                    var used = (d["_tokens_used"] || 0), lim = (d["_window_limit"] || 0)
                    theme.aiClTokens = used ? (used / 1e6).toFixed(2) + "M / " + (lim / 1e6).toFixed(1) + "M" : ""
                    var rateH = Math.round((d["_rate_per_hour"] || 0) / 1000)
                    theme.aiClRate = rateH > 0 ? rateH + "k tok/h" : ""
                    theme.aiClToday = parseInt(d._today_tokens) || 0
                } catch (e) {
                    theme.aiClHas = false; theme.aiClFresh = false
                    theme.aiClPct5h = 0; theme.aiClPct7d = 0
                    theme.aiClBlocked = false; theme.aiClTokens = ""; theme.aiClRate = ""
                    theme.aiClReset5hTs = 0; theme.aiClReset7dTs = 0; theme.aiClToday = 0
                }
            }
        }
    }

    Process {
        id: aiReadCodex
        command: ["bash", "-c",
            "f=\"$HOME/.cache/codex-usage.json\"; stat -c %Y \"$f\" 2>/dev/null; cat \"$f\" 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                var raw = this.text, nl = raw.indexOf("\n")
                var mtime = nl > 0 ? (parseInt(raw.substring(0, nl)) || 0) : 0
                var ageOk = mtime > 0 && (Date.now() / 1000 - mtime) < 900
                try {
                    var d = JSON.parse((nl > 0 ? raw.substring(nl + 1) : "").trim())
                    theme.aiApplyCodexCache(d, ageOk)
                } catch (e) {
                    theme.aiResetCodexUsage()
                }
            }
        }
    }

    Process {
        id: aiReadOpenCode
        command: ["bash", "-c",
            "f=\"$HOME/.cache/opencode-usage.json\"; stat -c %Y \"$f\" 2>/dev/null; cat \"$f\" 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                var raw = this.text, nl = raw.indexOf("\n")
                var mtime = nl > 0 ? (parseInt(raw.substring(0, nl)) || 0) : 0
                var ageOk = mtime > 0 && (Date.now() / 1000 - mtime) < 900
                try {
                    var d = JSON.parse((nl > 0 ? raw.substring(nl + 1) : "").trim())
                    theme.aiOcHas = true
                    theme.aiOcFresh = ageOk && d._source !== "stale"
                    theme.aiOcPct5h = theme.aiPct(d["5h-utilization"])
                    theme.aiOcPct7d = theme.aiPct(d["7d-utilization"])
                    theme.aiOcPlan = d._plan || ""
                    var ocUsed = (d["_tokens_used"] || 0), ocLim = (d["_window_limit"] || 0)
                    theme.aiOcTokens = ocUsed ? (ocUsed / 1e6).toFixed(2) + "M / " + (ocLim / 1e6).toFixed(1) + "M" : ""
                    var ocRateH = Math.round((d["_rate_per_hour"] || 0) / 1000)
                    theme.aiOcRate = ocRateH > 0 ? ocRateH + "k tok/h" : ""
                    theme.aiOcToday = parseInt(d._today_tokens) || 0
                    theme.aiOcModel = d._model || ""
                    theme.aiOcModels = d._models instanceof Array ? d._models : []
                } catch (e) {
                    theme.aiOcHas = false; theme.aiOcFresh = false
                    theme.aiOcPct5h = 0; theme.aiOcPct7d = 0
                    theme.aiOcPlan = ""; theme.aiOcTokens = ""; theme.aiOcRate = ""; theme.aiOcModel = ""
                    theme.aiOcToday = 0; theme.aiOcModels = []
                }
            }
        }
    }

    function refreshAiUsage(selectedOnly) {
        aiClockTick++
        var only = selectedOnly === true
        if (!only || aiTool === "claude") {
            aiReadClaude.running = false; aiReadClaude.running = true
        }
        if (!only || aiTool === "codex") {
            aiReadCodex.running = false;  aiReadCodex.running = true
        }
        if (!only || aiTool === "opencode") {
            aiReadOpenCode.running = false; aiReadOpenCode.running = true
        }
    }

    Timer {
        // 30s normally; 5s while the AI panel is open (responsive when looked at)
        interval: theme.aiUsageVisible ? 5000 : 30000
        running: true; repeat: true; triggeredOnStart: true
        onTriggered: theme.refreshAiUsage(theme.aiUsageVisible)
    }

    // ── Central system telemetry ──
    // One ShellRoot-level sampler feeds all monitor BarSlots. This replaces
    // per-widget bash/awk polling for CPU and memory, so adding monitors does not
    // multiply these status process chains.
    property int systemCpuPercent: 0
    property var systemCpuHistory: []
    property var systemCpuPerCore: []
    readonly property int systemCpuMaxSamples: 30
    property real _systemCpuPrevIdle: -1
    property real _systemCpuPrevTotal: -1
    property var _systemCpuPrevIdlePerCore: []
    property var _systemCpuPrevTotalPerCore: []

    property int systemMemTotalMiB: 0
    property int systemMemAvailMiB: 0
    property int systemMemFreeMiB: 0
    property int systemMemBuffersMiB: 0
    property int systemMemCachedMiB: 0
    readonly property int systemMemUsedMiB: Math.max(0, systemMemTotalMiB - systemMemAvailMiB)
    readonly property int systemMemPercent: systemMemTotalMiB > 0
        ? Math.max(0, Math.min(100, Math.round(systemMemUsedMiB / systemMemTotalMiB * 100)))
        : 0
    readonly property real systemMemUsedGiB: systemMemUsedMiB / 1024
    readonly property real systemMemTotalGiB: systemMemTotalMiB / 1024

    function parseSystemCpu(text) {
        var lines = String(text || "").split("\n")
        if (lines.length === 0 || lines[0].indexOf("cpu ") !== 0) return
        var parts = lines[0].trim().split(/\s+/)
        if (parts.length < 8) return

        var idle = parseFloat(parts[4]) + parseFloat(parts[5])
        var total = 0
        for (var i = 1; i < parts.length; i++) {
            var v = parseFloat(parts[i])
            if (!isNaN(v)) total += v
        }
        if (isNaN(idle) || isNaN(total) || total <= 0) return

        if (_systemCpuPrevTotal >= 0 && total > _systemCpuPrevTotal) {
            var totalDelta = total - _systemCpuPrevTotal
            var idleDelta = idle - _systemCpuPrevIdle
            var busy = totalDelta > 0 ? Math.round((totalDelta - idleDelta) / totalDelta * 100) : 0
            systemCpuPercent = Math.max(0, Math.min(100, busy))

            var h = systemCpuHistory.slice()
            h.push(systemCpuPercent / 100)
            if (h.length > systemCpuMaxSamples) h.shift()
            systemCpuHistory = h
        }

        _systemCpuPrevIdle = idle
        _systemCpuPrevTotal = total

        // per-core (line 1+: "cpuN user nice system idle iowait ...")
        var perCore = []
        for (var li = 1; li < lines.length; li++) {
            var m = lines[li].match(/^cpu(\d+)\s+(.*)$/)
            if (!m) break
            var idxCore = parseInt(m[1])
            var cp = m[2].trim().split(/\s+/)
            if (cp.length < 5) continue
            var cIdle = parseFloat(cp[3]) + parseFloat(cp[4])
            var cTotal = 0
            for (var ci = 0; ci < cp.length; ci++) {
                var cv = parseFloat(cp[ci])
                if (!isNaN(cv)) cTotal += cv
            }
            if (isNaN(cIdle) || isNaN(cTotal) || cTotal <= 0) continue
            var pIdle = _systemCpuPrevIdlePerCore[idxCore]
            var pTotal = _systemCpuPrevTotalPerCore[idxCore]
            var pct = perCore[idxCore] !== undefined ? perCore[idxCore] : (systemCpuPerCore[idxCore] || 0)
            if (pTotal !== undefined && cTotal > pTotal) {
                var tDelta = cTotal - pTotal
                var iDelta = cIdle - pIdle
                pct = tDelta > 0 ? Math.max(0, Math.min(100, Math.round((tDelta - iDelta) / tDelta * 100))) : 0
            }
            perCore[idxCore] = pct
            _systemCpuPrevIdlePerCore[idxCore] = cIdle
            _systemCpuPrevTotalPerCore[idxCore] = cTotal
        }
        if (perCore.length > 0) systemCpuPerCore = perCore
    }

    function parseSystemMem(text) {
        var total = 0, avail = 0, free = 0, buffers = 0, cached = 0
        var lines = String(text || "").split("\n")
        for (var i = 0; i < lines.length; i++) {
            var parts = lines[i].trim().split(/\s+/)
            if (parts.length < 2) continue
            var value = parseInt(parts[1])
            if (isNaN(value)) continue
            if (parts[0] === "MemTotal:") total = value
            else if (parts[0] === "MemAvailable:") avail = value
            else if (parts[0] === "MemFree:") free = value
            else if (parts[0] === "Buffers:") buffers = value
            else if (parts[0] === "Cached:") cached = value
        }
        if (total <= 0) return
        systemMemTotalMiB = Math.round(total / 1024)
        systemMemAvailMiB = Math.round(avail / 1024)
        systemMemFreeMiB = Math.round(free / 1024)
        systemMemBuffersMiB = Math.round(buffers / 1024)
        systemMemCachedMiB = Math.round(cached / 1024)
    }

    FileView {
        id: systemCpuFile
        path: "/proc/stat"
        onLoaded: theme.parseSystemCpu(systemCpuFile.text())
    }

    FileView {
        id: systemMemFile
        path: "/proc/meminfo"
        onLoaded: theme.parseSystemMem(systemMemFile.text())
    }

    Timer {
        interval: (theme.modSystemStats || theme.systemStatsVisible) ? 2000 : 10000
        running: true; repeat: true; triggeredOnStart: true
        onTriggered: {
            systemCpuFile.reload()
            systemMemFile.reload()
        }
    }

    // ── BTC price (Bitcoin), central poller shared by bar pill + panel ──
    // Ported from the "gpatkinson.btc-price" Omarchy plugin (MIT) — same
    // CoinGecko endpoint, 15-minute poll, ₿-prefixed price label, bitcoin-
    // orange/default color toggle persisted to the same state file path the
    // upstream plugin uses, so the preference isn't orphaned if the user
    // ever also installs it inside omarchy-shell.
    property real btcPriceUsd: 0
    property real btcPriceChange24h: 0
    property int  btcPriceUpdatedAt: 0
    property string btcPriceLabel: ""     // "" until first successful fetch (keeps the pill hidden)
    property bool btcPriceLoading: false
    property int  btcPriceRetries: 0
    property bool btcUseOrange: true

    // Extra market detail — hybrid sourcing: headline price/24h-change/
    // sparkline stay on CoinGecko (broad multi-exchange aggregate — the
    // number the pill/panel lead with); bid/ask/spread/high/low/volume come
    // from a second, small request straight to Bitfinex's public ticker
    // instead, since those are inherently one real exchange's order-book
    // data — CoinGecko has no aggregated bid/ask of its own to give.
    property real btcPriceHigh24h: 0
    property real btcPriceLow24h: 0
    property real btcPriceVolume24h: 0    // BTC units (Bitfinex's native VOLUME field), not USD
    property real btcPriceBid: 0
    property real btcPriceAsk: 0
    property real btcPriceSpreadPct: 0
    readonly property string btcSpreadExchange: "Bitfinex"
    property bool btcFxLoading: false
    property int  btcFxRetries: 0
    readonly property bool btcAnyLoading: btcPriceLoading || btcFxLoading
    property var   btcSparkline: []       // ~168 hourly points, last 7 days
    readonly property color btcPriceColor: btcUseOrange ? "#f7931a" : ink
    readonly property color btcChangeColorUp: "#4ade80"
    readonly property color btcChangeColorDown: "#f87171"
    readonly property color btcChangeColor: btcPriceChange24h >= 0 ? btcChangeColorUp : btcChangeColorDown

    readonly property string btcPriceApiUrl:
        "https://api.coingecko.com/api/v3/coins/bitcoin"
        + "?localization=false&tickers=false&market_data=true"
        + "&community_data=false&developer_data=false&sparkline=true"

    // Bitfinex's public ticker for tBTCUSD — a plain JSON array, no auth,
    // no rate-limit budget to worry about (unlike CoinGecko's free tier):
    // [BID, BID_SIZE, ASK, ASK_SIZE, DAILY_CHANGE, DAILY_CHANGE_RELATIVE,
    //  LAST_PRICE, VOLUME, HIGH, LOW, ...]. Only indices 0/2/7/8/9 are used.
    readonly property string btcFxApiUrl: "https://api-pub.bitfinex.com/v2/ticker/tBTCUSD"

    function btcFormatPrice(usd) {
        var n = parseFloat(usd)
        if (isNaN(n)) return ""
        var str = String(Math.round(n))
        var out = "", count = 0
        for (var i = str.length - 1; i >= 0; i--) {
            if (count > 0 && count % 3 === 0) out = "," + out
            out = str[i] + out
            count++
        }
        return "$" + out
    }
    function btcFormatChange(change) {
        var n = parseFloat(change)
        if (isNaN(n)) return ""
        return (n >= 0 ? "+" : "") + n.toFixed(2) + "%"
    }
    function btcFormatVolume(v) {
        var n = parseFloat(v)
        if (isNaN(n)) return ""
        if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B"
        if (n >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M"
        if (n >= 1e3) return "$" + (n / 1e3).toFixed(2) + "K"
        return "$" + n.toFixed(0)
    }
    function btcFormatBtcAmount(v) {
        var n = parseFloat(v)
        if (isNaN(n)) return ""
        var str = n.toFixed(2)
        var parts = str.split(".")
        var intPart = parts[0], out = "", count = 0
        for (var i = intPart.length - 1; i >= 0; i--) {
            if (count > 0 && count % 3 === 0) out = "," + out
            out = intPart[i] + out
            count++
        }
        return out + "." + parts[1] + " BTC"
    }
    function btcFormatUpdated(ts) {
        var t = parseInt(ts)
        if (!t) return ""
        var d = new Date(t * 1000)
        var h = String(d.getHours()).padStart(2, "0")
        var m = String(d.getMinutes()).padStart(2, "0")
        return h + ":" + m
    }

    function btcPriceRefresh(force) {
        if (btcPriceProc.running) {
            if (!force) return
            btcPriceProc.running = false
        }
        btcPriceRetries = 0
        btcPriceLoading = true
        btcPriceProc.running = true

        if (btcFxProc.running) {
            if (force) btcFxProc.running = false
        }
        if (force || !btcFxProc.running) {
            btcFxRetries = 0
            btcFxLoading = true
            btcFxProc.running = true
        }
    }

    function btcScheduleRetry() {
        if (btcPriceRetries >= 3) return
        btcPriceRetries++
        btcRetryTimer.restart()
    }
    function btcFxScheduleRetry() {
        if (btcFxRetries >= 3) return
        btcFxRetries++
        btcFxRetryTimer.restart()
    }

    Process {
        id: btcPriceProc
        command: ["curl", "-fsS", "--max-time", "10", theme.btcPriceApiUrl]
        stdout: StdioCollector {
            waitForEnd: true
            onStreamFinished: {
                theme.btcPriceLoading = false
                var raw = String(this.text || "").trim()
                if (!raw) { theme.btcScheduleRetry(); return }
                try {
                    var data = JSON.parse(raw)
                    var md = data && data.market_data
                    var usd = parseFloat(md && md.current_price ? md.current_price.usd : NaN)
                    if (isNaN(usd)) { theme.btcScheduleRetry(); return }
                    theme.btcPriceUsd = usd
                    theme.btcPriceChange24h = parseFloat(md.price_change_percentage_24h) || 0
                    var lastUpdated = data.last_updated ? Date.parse(data.last_updated) : NaN
                    theme.btcPriceUpdatedAt = isNaN(lastUpdated) ? 0 : Math.round(lastUpdated / 1000)
                    theme.btcPriceLabel = "₿" + theme.btcFormatPrice(usd)
                    theme.btcSparkline = (md.sparkline_7d && md.sparkline_7d.price) || []

                    theme.btcPriceRetries = 0
                } catch (e) {
                    theme.btcScheduleRetry()
                }
            }
        }
        onExited: function(exitCode) {
            if (exitCode !== 0) { theme.btcPriceLoading = false; theme.btcScheduleRetry() }
        }
    }

    Timer {
        id: btcRetryTimer
        interval: 5000
        onTriggered: if (!btcPriceProc.running) btcPriceProc.running = true
    }

    // Bid/ask/spread/high/low/volume — real order-book data from Bitfinex,
    // polled alongside (not instead of) the CoinGecko headline-price fetch.
    Process {
        id: btcFxProc
        command: ["curl", "-fsS", "--max-time", "10", theme.btcFxApiUrl]
        stdout: StdioCollector {
            waitForEnd: true
            onStreamFinished: {
                theme.btcFxLoading = false
                var raw = String(this.text || "").trim()
                if (!raw) { theme.btcFxScheduleRetry(); return }
                try {
                    var t = JSON.parse(raw)
                    if (!Array.isArray(t) || t.length < 10) { theme.btcFxScheduleRetry(); return }
                    var bid = parseFloat(t[0]), ask = parseFloat(t[2])
                    var high = parseFloat(t[8]), low = parseFloat(t[9])
                    var volume = parseFloat(t[7])
                    if (isNaN(bid) || isNaN(ask)) { theme.btcFxScheduleRetry(); return }
                    theme.btcPriceBid = bid
                    theme.btcPriceAsk = ask
                    theme.btcPriceHigh24h = isNaN(high) ? 0 : high
                    theme.btcPriceLow24h = isNaN(low) ? 0 : low
                    theme.btcPriceVolume24h = isNaN(volume) ? 0 : volume
                    var mid = (bid + ask) / 2
                    theme.btcPriceSpreadPct = mid > 0 ? ((ask - bid) / mid) * 100 : 0
                    theme.btcFxRetries = 0
                } catch (e) {
                    theme.btcFxScheduleRetry()
                }
            }
        }
        onExited: function(exitCode) {
            if (exitCode !== 0) { theme.btcFxLoading = false; theme.btcFxScheduleRetry() }
        }
    }

    Timer {
        id: btcFxRetryTimer
        interval: 5000
        onTriggered: if (!btcFxProc.running) btcFxProc.running = true
    }

    Timer {
        interval: 15 * 60 * 1000   // 15 minutes, matches upstream plugin's CoinGecko free-tier budget
        running: true; repeat: true; triggeredOnStart: true
        onTriggered: theme.btcPriceRefresh(false)
    }

    readonly property string btcStatePath: Quickshell.env("HOME") + "/.local/state/omarchy/settings/btc-price.json"

    function btcToggleColor() {
        btcUseOrange = !btcUseOrange
        btcColorSaveProc.command = ["sh", "-c",
            "mkdir -p \"" + btcStatePath.replace(/\/[^\/]+$/, "") + "\""
            + " && printf '{\"useOrange\":" + (btcUseOrange ? "true" : "false") + "}' > \"" + btcStatePath + "\""]
        btcColorSaveProc.running = false
        btcColorSaveProc.running = true
    }

    Process { id: btcColorSaveProc }

    FileView {
        id: btcColorFile
        path: theme.btcStatePath
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                var d = JSON.parse(btcColorFile.text() || "{}")
                if (d && d.useOrange !== undefined) theme.btcUseOrange = d.useOrange === true
            } catch (e) { /* keep default */ }
        }
    }

    // ── Memory panel state ──
    property bool memVisible: false
    onMemVisibleChanged: popupOpened("memVisible")

    // ── Volume panel state ──
    property bool volVisible: false
    onVolVisibleChanged: popupOpened("volVisible")

    // ── Control center state ──
    property bool controlVisible: false
    onControlVisibleChanged: {
        popupOpened("controlVisible")
        if (!controlVisible) { splitsSubVisible = false; wwSubVisible = false }
    }

    // ── Split state (controlled by Bar + ControlPanel) ──
    property bool splitLeft:   false
    property bool splitRight:  false
    property bool splitArch:   false
    property bool splitMon:    false
    property bool splitNet:    false
    property bool splitMprisL: false
    property int barAnim: 0   // 0=off, 1=stream, 2=surge, 3=bolt, 4=bolt2, 5=stream2, 6=surge2, 7=reactor, 8=quotes

    // ── Bar layout / unlock (drag&drop reorder). barUnlocked is transient. ──
    property bool barUnlocked: false
    // split-control hooks called by the ControlPanel split sub-panel.
    property var  fnSplitAll:      function () { theme.splitAllBars() }
    property var  fnMergeAll:      function () { theme.mergeAllBars() }
    property var  fnDefaultLayout: function () { theme.resetAllBarLayouts() }
    property bool splitsSubVisible: false
    property bool wwSubVisible: false   // "Widgets & Workspaces" fly-out

    // Legacy split booleans are kept only for cache compatibility. The active
    // split system lives in BarSlot's per-gap arrays; ParticleStream is gated by
    // the real run count there, so barAnim no longer follows these old flags.
    function mergeAllSplits() {
        splitLeft = false; splitRight = false; splitArch = false;
        splitMon = false; splitNet = false; splitMprisL = false;
    }

    // ── Control-panel state persistence (splits / anim / accent) ──
    // Survives bar restarts via a tiny cache file; no extra deps (same Process+cat
    // pattern used elsewhere). _splitsLoaded gates saving so the initial restore
    // doesn't immediately write back over itself.
    readonly property string splitsCachePath: Quickshell.env("HOME") + "/.cache/quickshell_splits"
    property bool _splitsLoaded: false

    onSplitArchChanged:      if (_splitsLoaded) saveSplits()
    onSplitMonChanged:       if (_splitsLoaded) saveSplits()
    onSplitNetChanged:       if (_splitsLoaded) saveSplits()
    onSplitMprisLChanged:    if (_splitsLoaded) saveSplits()
    onBarAnimChanged:        if (_splitsLoaded) saveSplits()
    onBarColorChanged:       if (_splitsLoaded) saveSplits()

    // Build the command imperatively (not as a binding): a bound `command` can
    // still hold the pre-toggle value when the Process runs, saving stale state.
    function saveSplits() {
        var line = (splitArch   ? "1" : "0") + " "
                 + (splitMon     ? "1" : "0") + " "
                 + (splitMprisL  ? "1" : "0") + " "
                 + (splitNet     ? "1" : "0") + " "
                 + barAnim + " "
                 + barColor
        splitSaveProc.command = ["bash", "-c",
            "mkdir -p \"$(dirname '" + splitsCachePath + "')\" && echo '" + line + "' > '" + splitsCachePath + "'"]
        splitSaveProc.running = false
        splitSaveProc.running = true
    }

    Process {
        id: splitLoadProc
        command: ["cat", theme.splitsCachePath]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                var parts = this.text.trim().split(" ")
                if (parts.length >= 5) {
                    theme.splitArch      = parts[0] === "1"
                    theme.splitMon       = parts[1] === "1"
                    theme.splitMprisL    = parts[2] === "1"
                    theme.splitNet       = parts[3] === "1"
                    var ba = parseInt(parts[4]); theme.barAnim = (ba >= 0 && ba <= 8) ? ba : 0
                    if (parts.length >= 6) {
                        var bc = parts[5]
                        if (bc === "1" || bc === "0") theme.barColor = "color01"
                        else if (bc === "green" || bc === "color2") theme.barColor = "color02"
                        else if (bc === "yellow" || bc === "color3") theme.barColor = "color03"
                        else if (theme.barColorValid(bc)) theme.barColor = theme.normalizedPaletteId(bc)
                    }
                }
                theme._splitsLoaded = true
            }
        }
    }

    Process { id: splitSaveProc }   // command is set imperatively in saveSplits()

    // ── module enable flags (controlled by ControlPanel) ──
    property bool modStatus:     true
    property bool modMemory:     true
    property bool modCpu:        true
    property bool modVolume:     true
    property bool modWeather:    true
    property bool modNetwork:    true
    property string networkMode: "none"   // mirrored from NetworkWidget: wifi/ethernet/none
    property bool omarchyUpdateAvail: false   // mirrored from UpdateWidget (6h poll)
    // Centralized status indicators. These live on Theme so BarSlot-per-monitor
    // widgets don't each spawn their own status poller.
    property bool stayAwake: false            // idle lock disabled / stay-awake indicator
    readonly property bool hypridleAwake: stayAwake // compatibility alias for older modules
    property bool _idleBackendChecked: false
    property bool _idleOmarchyShellBackend: false
    property bool _idleOmarchyShellSystem: false
    property bool _omarchyBackendReprobePending: false
    property int _omarchyBackendRetryIndex: 0
    readonly property var _omarchyBackendRetryDelays: [2000, 5000, 15000]
    readonly property string omarchyShellConfigPath: Quickshell.env("HOME") + "/.config/omarchy/shell.json"
    readonly property string idleStatePath: Quickshell.env("HOME") + "/.local/state/omarchy/indicators/stay-awake"
    property bool notifSilenced: false        // notification do-not-disturb mode
    property bool _notifBackendChecked: false
    property bool _notifOmarchyShellBackend: false
    property bool _notifOmarchyShellSystem: false
    readonly property string notificationsStatePath: Quickshell.env("HOME") + "/.local/state/omarchy/notifications.json"
    property bool screenRecording: false
    property int screenRecordingElapsed: 0
    property string _screenRecordingPid: ""
    property string _screenRecordingElapsedProbePid: ""
    property int _screenRecordingBaseElapsed: 0
    property real _screenRecordingBaseMs: 0
    readonly property string screenRecordingStatePath: "/tmp/omarchy-screenrecord-filename"
    property bool _recordingRefreshPending: false
    property string voxState: "idle"          // idle/recording/transcribing
    property string voxHint: ""
    property bool voxAvailable: true
    readonly property bool _statusPollingWanted: modStatus || barAnim === 7
    readonly property bool _voxActive: voxState === "recording" || voxState === "transcribing"

    function refreshIdleStatus() {
        if (!_idleBackendChecked) return
        if (_idleOmarchyShellSystem) {
            idleStateFile.reload()
            return
        }
        if (!idleProc.running) idleProc.running = true
    }
    function refreshStatusIndicators() {
        refreshIdleStatus()
        refreshNotificationStatus()
    }
    function reprobeOmarchyShellBackends() {
        if (idleBackendProc.running || notifBackendProc.running) {
            _omarchyBackendReprobePending = true
            return
        }
        _omarchyBackendReprobePending = false
        idleBackendProc.running = true
        notifBackendProc.running = true
    }
    function finishOmarchyBackendReprobe() {
        if (idleBackendProc.running || notifBackendProc.running) return
        if (_omarchyBackendReprobePending) {
            omarchyBackendProbeDebounce.restart()
            return
        }
        scheduleOmarchyBackendRetry()
    }
    function omarchyBackendRetryNeeded() {
        return (_idleOmarchyShellSystem && !_idleOmarchyShellBackend)
            || (_notifOmarchyShellSystem && !_notifOmarchyShellBackend)
    }
    function scheduleOmarchyBackendRetry() {
        if (!omarchyBackendRetryNeeded()) {
            omarchyBackendRetryTimer.stop()
            _omarchyBackendRetryIndex = 0
            return
        }
        if (omarchyBackendConfirmTimer.running || omarchyBackendRetryTimer.running
                || _omarchyBackendRetryIndex >= _omarchyBackendRetryDelays.length) return
        omarchyBackendRetryTimer.interval = _omarchyBackendRetryDelays[_omarchyBackendRetryIndex]
        _omarchyBackendRetryIndex++
        omarchyBackendRetryTimer.restart()
    }
    function resetOmarchyBackendProbes() {
        omarchyBackendRetryTimer.stop()
        _omarchyBackendRetryIndex = 0
        omarchyBackendProbeDebounce.restart()
        omarchyBackendConfirmTimer.restart()
    }
    function parseNotificationsState(text) {
        try {
            var parsed = JSON.parse(String(text || "{}"))
            notifSilenced = parsed && parsed.dnd === true
        } catch (e) {
            notifSilenced = false
        }
    }
    function refreshNotificationStatus() {
        if (!_notifBackendChecked) return
        if (_notifOmarchyShellSystem) {
            notificationsStateFile.reload()
            return
        }
        if (!dndProc.running) dndProc.running = true
    }
    function refreshRecordingStatus() {
        if (recordingPidProc.running) {
            _recordingRefreshPending = true
            return
        }
        recordingPidProc.running = true
    }
    function reconcileSlowStatusIndicators() {
        refreshRecordingStatus()
    }
    function setScreenRecordingPid(pid) {
        pid = String(pid || "").trim()
        if (pid === _screenRecordingPid) return

        _screenRecordingPid = pid
        if (pid === "") {
            screenRecording = false
            screenRecordingElapsed = 0
            _screenRecordingBaseElapsed = 0
            _screenRecordingBaseMs = 0
            _screenRecordingElapsedProbePid = ""
            return
        }

        screenRecording = true
        screenRecordingElapsed = 0
        _screenRecordingBaseElapsed = 0
        _screenRecordingBaseMs = Date.now()
        _screenRecordingElapsedProbePid = pid
        recordingElapsedProc.command = ["ps", "-o", "etimes=", "-p", pid]
        recordingElapsedProc.running = false
        recordingElapsedProc.running = true
    }
    function updateScreenRecordingElapsed() {
        if (!screenRecording || _screenRecordingBaseMs <= 0) return
        screenRecordingElapsed = _screenRecordingBaseElapsed + Math.floor((Date.now() - _screenRecordingBaseMs) / 1000)
    }
    function refreshVoxtypeStatus() {
        if (!voxAvailable && !modStatus && barAnim !== 7) return
        if (voxProc.running) return
        voxProc.running = true
    }

    Process {
        id: idleBackendProc
        command: ["bash", "-c", "root=${OMARCHY_PATH:-/usr/share/omarchy}; [[ -f $root/shell/plugins/services/idle/manifest.json ]] || exit 2; command -v omarchy-shell >/dev/null 2>&1 && OMARCHY_PATH=$root omarchy-shell idle status >/dev/null 2>&1"]
        running: true
        onExited: (exitCode) => {
            theme._idleOmarchyShellSystem = exitCode !== 2
            theme._idleOmarchyShellBackend = exitCode === 0
            theme._idleBackendChecked = true
            theme.refreshIdleStatus()
            theme.finishOmarchyBackendReprobe()
        }
    }

    FileView {
        id: idleStateFile
        path: theme.idleStatePath
        watchChanges: theme._idleOmarchyShellSystem
        printErrors: false
        onFileChanged: idleStateFile.reload()
        onLoaded: {
            if (theme._idleOmarchyShellSystem) theme.stayAwake = true
        }
        onLoadFailed: {
            if (theme._idleOmarchyShellSystem) theme.stayAwake = false
        }
    }

    Process {
        id: notifBackendProc
        command: ["bash", "-c", "root=${OMARCHY_PATH:-/usr/share/omarchy}; [[ -f $root/shell/plugins/notifications/manifest.json ]] || exit 2; command -v omarchy-shell >/dev/null 2>&1 && OMARCHY_PATH=$root omarchy-shell notifications ping 2>/dev/null | grep -Fxq ok"]
        running: true
        onExited: (exitCode) => {
            theme._notifOmarchyShellSystem = exitCode !== 2
            theme._notifOmarchyShellBackend = exitCode === 0
            theme._notifBackendChecked = true
            theme.refreshNotificationStatus()
            theme.finishOmarchyBackendReprobe()
        }
    }

    FileView {
        id: notificationsStateFile
        path: theme.notificationsStatePath
        watchChanges: theme._notifOmarchyShellSystem
        printErrors: false
        onFileChanged: notificationsStateFile.reload()
        onLoaded: {
            if (theme._notifOmarchyShellSystem) theme.parseNotificationsState(notificationsStateFile.text())
        }
        onLoadFailed: {
            if (theme._notifOmarchyShellSystem) theme.notifSilenced = false
        }
    }

    Timer {
        id: omarchyBackendProbeDebounce
        interval: 250
        repeat: false
        onTriggered: theme.reprobeOmarchyShellBackends()
    }

    Timer {
        id: omarchyBackendRetryTimer
        repeat: false
        onTriggered: theme.reprobeOmarchyShellBackends()
    }

    Timer {
        id: omarchyBackendConfirmTimer
        interval: 2000
        repeat: false
        onTriggered: {
            theme._omarchyBackendRetryIndex = Math.max(1, theme._omarchyBackendRetryIndex)
            theme.reprobeOmarchyShellBackends()
        }
    }

    FileView {
        id: omarchyShellConfigFile
        path: theme.omarchyShellConfigPath
        watchChanges: true
        printErrors: false
        onFileChanged: {
            omarchyShellConfigFile.reload()
            theme.resetOmarchyBackendProbes()
        }
    }

    Process {
        id: idleProc
        command: ["pgrep", "-x", "hypridle"]
        running: false
        onExited: (exitCode) => {
            if (!theme._idleOmarchyShellSystem) theme.stayAwake = exitCode !== 0
        }
    }

    Process {
        id: dndProc
        command: ["makoctl", "mode"]
        running: false
        onExited: (exitCode) => {
            if (exitCode !== 0 && !theme._notifOmarchyShellSystem) theme.notifSilenced = false
        }
        stdout: StdioCollector {
            onStreamFinished: {
                if (!theme._notifOmarchyShellSystem) theme.notifSilenced = this.text.indexOf("do-not-disturb") >= 0
            }
        }
    }

    Process {
        id: recordingPidProc
        command: ["pgrep", "-o", "-f", "^gpu-screen-recorder"]
        running: false
        onExited: (exitCode) => {
            if (exitCode !== 0) theme.setScreenRecordingPid("")
            if (theme._recordingRefreshPending) {
                theme._recordingRefreshPending = false
                theme.refreshRecordingStatus()
            }
        }
        stdout: StdioCollector {
            onStreamFinished: {
                var parts = this.text.trim().split(/\s+/)
                theme.setScreenRecordingPid(parts[0] || "")
            }
        }
    }

    FileView {
        id: screenRecordingStateFile
        path: theme.screenRecordingStatePath
        watchChanges: true
        printErrors: false
        onFileChanged: {
            screenRecordingStateFile.reload()
            theme.refreshRecordingStatus()
        }
        onLoaded: theme.refreshRecordingStatus()
        onLoadFailed: theme.refreshRecordingStatus()
    }

    Process {
        id: recordingElapsedProc
        command: ["true"]
        running: false
        stdout: StdioCollector {
            onStreamFinished: {
                if (theme._screenRecordingElapsedProbePid !== theme._screenRecordingPid) return
                var elapsed = parseInt(this.text.trim())
                if (isNaN(elapsed)) elapsed = 0
                theme._screenRecordingBaseElapsed = Math.max(0, elapsed)
                theme._screenRecordingBaseMs = Date.now()
                theme.updateScreenRecordingElapsed()
            }
        }
    }

    Timer {
        interval: 1500
        running: theme._statusPollingWanted
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.refreshStatusIndicators()
    }

    Timer {
        interval: 45000
        running: theme._statusPollingWanted
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.reconcileSlowStatusIndicators()
    }

    Timer {
        interval: 1000
        running: theme.screenRecording
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.updateScreenRecordingElapsed()
    }

    Process {
        id: voxProc
        command: ["bash", "-c",
            "if command -v voxtype >/dev/null 2>&1; then " +
            "timeout 1 voxtype status --extended --format json 2>/dev/null | jq -r '[(.class // .alt // \"idle\"), ((.tooltip // \"\") | split(\"\\n\")[0])] | @tsv' 2>/dev/null; " +
            "else echo 'MISSING'; fi"
        ]
        running: false
        stdout: StdioCollector {
            onStreamFinished: {
                var parts = this.text.trim().split("\t")
                if (parts[0] === "MISSING") {
                    theme.voxAvailable = false
                    theme.voxState = "idle"
                    theme.voxHint = ""
                    return
                }
                theme.voxAvailable = true
                theme.voxState = parts[0] || "idle"
                theme.voxHint = parts[1] || ""
            }
        }
    }
    Timer {
        interval: theme._voxActive ? 1000 : (theme.voxAvailable ? 10000 : 60000)
        running: theme._statusPollingWanted
        repeat: true
        triggeredOnStart: true
        onTriggered: theme.refreshVoxtypeStatus()
    }
    // battery presence (laptop) — drives the Battery indicator tile's visibility (shown only
    // where a battery exists, like Brightness uses hasBacklight). Direct UPower check, event-driven.
    readonly property bool hasBattery: UPower.displayDevice !== null && UPower.displayDevice.isLaptopBattery
    // NetworkManager active (Omarchy 4.0) → the panel's iwctl scan/connect won't work,
    // so it shows an "open nmtui" button instead of an empty list
    property bool useNM: false
    Process {
        command: ["bash", "-c", "systemctl is-active --quiet NetworkManager && echo 1 || echo 0"]
        running: true
        stdout: StdioCollector { onStreamFinished: theme.useNM = this.text.trim() === "1" }
    }

    // ── wifi/bluetooth settings launchers (Omarchy way, via uwsm-app) ──
    // iwd (Omarchy 3.8.x) → impala/bluetui through omarchy-launch-*; if NetworkManager
    // is the active backend (Omarchy 4.0) → nmtui instead. Quattro removed the
    // dedicated Bluetooth launcher; prefer a retained bluetui, then bluetoothctl.
    readonly property string launchWifiCmd: "if systemctl is-active --quiet NetworkManager 2>/dev/null; then omarchy-launch-or-focus-tui nmtui; else omarchy-launch-wifi; fi"
    readonly property string launchBtCmd:   "if command -v omarchy-launch-bluetooth >/dev/null 2>&1; then exec omarchy-launch-bluetooth; elif command -v omarchy-launch-or-focus-tui >/dev/null 2>&1; then if command -v bluetui >/dev/null 2>&1; then command -v rfkill >/dev/null 2>&1 && rfkill unblock bluetooth >/dev/null 2>&1 || true; exec omarchy-launch-or-focus-tui bluetui; elif command -v bluetoothctl >/dev/null 2>&1; then command -v rfkill >/dev/null 2>&1 && rfkill unblock bluetooth >/dev/null 2>&1 || true; exec omarchy-launch-or-focus-tui bluetoothctl; fi; fi; command -v notify-send >/dev/null 2>&1 && notify-send -a QS-Shell -u critical 'Bluetooth settings unavailable' 'No supported Bluetooth settings backend was found' || true; exit 0"
    property bool modPower:      false   // default off (toggle in ControlPanel)
    property bool modBluetooth:  false   // default off (toggle in ControlPanel)
    property bool modBrightness: true
    property bool modMedia:      true
    property bool modQuick:      true    // G10 group pill (idle-inhibitor · media · theme)
    property bool modMpris:      true    // G9 now-playing / mpris pill
    property bool modClaude:     false   // default off (toggle in ControlPanel)
    property bool modSystemStats: true   // G17 combined CPU+GPU+Memory+Storage pill
    property bool modRadioAtlas:  true   // G16 radio-atlas trigger pill
    property bool modBtcPrice:    true   // G18 Bitcoin price pill

    // Per-widget compact display modes. Defaults are full-width for backwards
    // compatibility; ControlPanel toggles persist these below.
    property bool compactNetwork:    false
    property bool compactBattery:    false
    property bool compactBrightness: false
    property bool compactCpu:        false
    property bool compactMemory:     false
    property bool compactVolume:     false
    property bool compactBluetooth:  false
    property bool compactPower:      false
    property bool compactMpris:      false

    // backlight presence — set by BrightnessWidget once it probes /sys/class/backlight.
    // ControlPanel uses this to hide the Brightness toggle on desktops without one.
    property bool hasBacklight:  false

    // ── workspace display mode ──
    property string workspaceMode: "10"   // "10", "5", "active"
    // ── workspace display style (orthogonal to mode; persisted) ──
    property string workspaceStyle: "default"   // "default", "numbers", "magic"

    // ── bar screen position (persisted) ──
    property string barPosition: "top"   // "top" or "bottom"

    // ── picker visual style (theme/wallpaper/screenshot/video pickers) ──
    property string pickerStyle: "tanzaku"   // "tanzaku", "hearthstone", "carousel"
    property string launcherLogoMode: "text"     // "text" or "icon"
    property string launcherLogoText: "omarchy"  // "omarchy", "hyprland", "arch", or "omacom"
    property string launcherLogoIcon: "omarchy"  // see launcherLogoIconGlyph()
    property bool   weatherImperial: false   // false = °C / km·h, true = °F / mph
    property bool   clock12h:        false   // legacy 24h/12h flag; superseded by the format ring below (still persisted for offset stability)

    // ── Bar clock label format ring ──
    // Right-clicking the bar time walks these in order and remembers the
    // landing spot. Strings + order are copied verbatim from Omarchy's stock
    // clock plugin (/usr/share/omarchy/shell/plugins/panels/clock/Model.js,
    // CLOCK_FORMATS) so the walk matches Omarchy Quattro's exactly. Persisted
    // as a ring index — field +36 of ~/.cache/quickshell_widgets.
    readonly property var clockFormatRing: [
        "dddd HH:mm",          // Friday 19:14
        "dddd h:mm AP",        // Friday 7:14 PM
        "HH:mm",               // 19:14
        "h:mm AP",             // 7:14 PM
        "ddd d MMM HH:mm",     // Fri 28 Aug 19:14
        "ddd d MMM h:mm AP",   // Fri 28 Aug 7:14 PM   ← default
        "d MMMM 'нед.' ww yyyy", // 28 августа нед. 35 2026
        "yyyy-MM-dd HH:mm"     // 2026-08-28 19:14
    ]
    property int clockFormatIndex: 5
    readonly property string clockFormat: {
        const n = clockFormatRing.length;
        return clockFormatRing[((clockFormatIndex % n) + n) % n];
    }
    // Whether the active format already prints a date/weekday — the separate
    // "Fri 28" bar label collapses when it does, so the date isn't shown twice.
    readonly property bool clockFormatShowsDate: /[dMy]/.test(clockFormat)
    function cycleClockFormat() {
        clockFormatIndex = (clockFormatIndex + 1) % clockFormatRing.length;
    }

    // ── widget/workspace state persistence ──
    readonly property string widgetsCachePath: Quickshell.env("HOME") + "/.cache/quickshell_widgets"
    property bool _widgetsLoaded: false
    property bool _compactResetting: false

    onModMemoryChanged:     if (_widgetsLoaded) saveWidgets()
    onModBrightnessChanged: if (_widgetsLoaded) saveWidgets()
    onModClaudeChanged:     if (_widgetsLoaded) saveWidgets()
    onModPowerChanged:      if (_widgetsLoaded) saveWidgets()
    onModBluetoothChanged:  if (_widgetsLoaded) saveWidgets()
    onModNetworkChanged:    if (_widgetsLoaded) saveWidgets()
    onModStatusChanged:     if (_widgetsLoaded) saveWidgets()
    onModQuickChanged:      if (_widgetsLoaded) saveWidgets()
    onModCpuChanged:        if (_widgetsLoaded) saveWidgets()
    onModVolumeChanged:     if (_widgetsLoaded) saveWidgets()
    onModMprisChanged:      if (_widgetsLoaded) saveWidgets()
    onModSystemStatsChanged: if (_widgetsLoaded) saveWidgets()
    onModRadioAtlasChanged:  if (_widgetsLoaded) saveWidgets()
    onModBtcPriceChanged:    if (_widgetsLoaded) saveWidgets()
    onAiToolChanged:        if (_widgetsLoaded) saveWidgets()
    onWorkspaceModeChanged: if (_widgetsLoaded) saveWidgets()
    onPickerStyleChanged:   if (_widgetsLoaded) saveWidgets()
    onLauncherLogoModeChanged: if (_widgetsLoaded) saveWidgets()
    onLauncherLogoTextChanged: if (_widgetsLoaded) saveWidgets()
    onLauncherLogoIconChanged: if (_widgetsLoaded) saveWidgets()
    onWeatherImperialChanged: if (_widgetsLoaded) saveWidgets()
    onClock12hChanged:        if (_widgetsLoaded) saveWidgets()
    onClockFormatIndexChanged: if (_widgetsLoaded) saveWidgets()
    onArchBadgePackagesChanged: if (_widgetsLoaded) saveWidgets()
    onArchBadgeThemesChanged:   if (_widgetsLoaded) saveWidgets()
    onArchBadgeShellChanged:    if (_widgetsLoaded) saveWidgets()
    onCompactNetworkChanged:    if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactBatteryChanged:    if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactBrightnessChanged: if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactCpuChanged:        if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactMemoryChanged:     if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactVolumeChanged:     if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactBluetoothChanged:  if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactPowerChanged:      if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onCompactMprisChanged:      if (_widgetsLoaded && !_compactResetting) saveWidgets()
    onStyleBorderChanged:      if (_widgetsLoaded) saveWidgets()
    onStyleShadowChanged:      if (_widgetsLoaded) saveWidgets()
    onStyleFrostChanged:       if (_widgetsLoaded) saveWidgets()
    onStyleRadiusSmallChanged: if (_widgetsLoaded) saveWidgets()
    onWorkspaceStyleChanged:   if (_widgetsLoaded) saveWidgets()
    onBarPositionChanged:      if (_widgetsLoaded) saveWidgets()

    function saveWidgets() {
        var line = (modMemory    ? "1" : "0") + " "
                 + (modBrightness ? "1" : "0") + " "
                 + (modClaude    ? "1" : "0") + " "
                 + (modPower     ? "1" : "0") + " "
                 + (modBluetooth ? "1" : "0") + " "
                 + workspaceMode + " "
                 + pickerStyle + " "
                 + (weatherImperial ? "1" : "0") + " "
                 + (clock12h        ? "1" : "0") + " "
                 + (modNetwork      ? "1" : "0") + " "
                 + (styleShadow      ? "1" : "0") + " "   // field +5 (was styleBorderless; value-compatible)
                 + (styleRadiusSmall ? "1" : "0") + " "
                 + (styleHeightMin   ? "1" : "0") + " "
                 + workspaceStyle + " "
                 + barPosition + " "
                 + (styleBorder      ? "1" : "0") + " "   // +10 (new; old caches → derived from styleShadow)
                 + (modStatus ? "1" : "0") + " "          // +11 group pill: status (arch/tray/notif)
                 + (modQuick  ? "1" : "0") + " "          // +12 group pill: quick (idle/media/theme)
                 + (modCpu    ? "1" : "0") + " "          // +13
                 + (modVolume ? "1" : "0") + " "          // +14
                 + (modMpris  ? "1" : "0") + " "          // +15 now-playing / mpris
                 + aiTool + " "                           // +16 AI tool shown in bar (claude/codex/opencode)
                 + (styleFrost ? "1" : "0") + " "         // +17 frost / lowered island opacity
                 + launcherLogoMode + " "                 // +18 launcher logo mode (text/icon)
                 + launcherLogoText + " "                 // +19 text logo id
                 + launcherLogoIcon + " "                 // +20 icon logo id
                 + (archBadgePackages ? "1" : "0") + " "  // +21 updater package badge
                 + (archBadgeThemes   ? "1" : "0") + " "  // +22 updater clean-theme badge
                 + (compactNetwork    ? "1" : "0") + " "  // +23 compact network pill
                 + (compactBattery    ? "1" : "0") + " "  // +24
                 + (compactBrightness ? "1" : "0") + " "  // +25
                 + (compactCpu        ? "1" : "0") + " "  // +26
                 + (compactMemory     ? "1" : "0") + " "  // +27
                 + (compactVolume     ? "1" : "0") + " "  // +28
                 + (compactBluetooth  ? "1" : "0") + " "  // +29
                 + (compactPower      ? "1" : "0") + " "  // +30
                 + (archBadgeShell    ? "1" : "0") + " "  // +31 updater shell badge
                 + (compactMpris      ? "1" : "0") + " "  // +32 V2 FULL / muse presentation
                 + (modSystemStats    ? "1" : "0") + " "  // +33
                 + (modRadioAtlas     ? "1" : "0") + " "  // +34
                 + (modBtcPrice       ? "1" : "0") + " "  // +35
                 + clockFormatIndex                       // +36 bar clock format ring index
        widgetSaveProc.command = ["bash", "-c",
            "echo '" + line + "' > '" + widgetsCachePath + "'"]
        widgetSaveProc.running = false
        widgetSaveProc.running = true
    }

    readonly property var launcherLogoTextOptions: ["omarchy", "hyprland", "arch", "omacom"]
    readonly property var launcherLogoIconOptions: ["omarchy", "hyprland", "arch", "grid", "spark", "power", "dragon", "mark", "nix", "branch", "rebel"]

    function launcherLogoTextIndex(id) {
        for (var i = 0; i < launcherLogoTextOptions.length; i++)
            if (launcherLogoTextOptions[i] === id) return i
        return 0
    }
    function launcherLogoIconIndex(id) {
        for (var i = 0; i < launcherLogoIconOptions.length; i++)
            if (launcherLogoIconOptions[i] === id) return i
        return 0
    }
    function launcherLogoTextValid(id) {
        return launcherLogoTextIndex(id) >= 0 && launcherLogoTextOptions[launcherLogoTextIndex(id)] === id
    }
    function launcherLogoIconValid(id) {
        return launcherLogoIconIndex(id) >= 0 && launcherLogoIconOptions[launcherLogoIconIndex(id)] === id
    }
    function nextLauncherLogoText() {
        launcherLogoText = launcherLogoTextOptions[(launcherLogoTextIndex(launcherLogoText) + 1) % launcherLogoTextOptions.length]
    }
    function nextLauncherLogoIcon() {
        launcherLogoIcon = launcherLogoIconOptions[(launcherLogoIconIndex(launcherLogoIcon) + 1) % launcherLogoIconOptions.length]
    }
    function launcherConfigValue(config, a, b, c) {
        if (!config) return undefined
        if (config[a] !== undefined) return config[a]
        if (b && config[b] !== undefined) return config[b]
        if (c && config[c] !== undefined) return config[c]
        return undefined
    }
    function applyLauncherConfig(config) {
        if (!config) return

        var launcher = config.launcher || config.logo || config
        var mode = launcherConfigValue(launcher, "launcherLogoMode", "logoMode", "mode")
        var text = launcherConfigValue(launcher, "launcherLogoText", "textLogo", "text")
        var icon = launcherConfigValue(launcher, "launcherLogoIcon", "iconLogo", "icon")

        if (mode === "text" || mode === "icon") launcherLogoMode = mode
        if (text !== undefined && launcherLogoTextValid(text)) launcherLogoText = text
        if (icon !== undefined && launcherLogoIconValid(icon)) launcherLogoIcon = icon
    }
    function launcherLogoLabel(id) {
        if (id === "omarchy") return "Omarchy"
        if (id === "hyprland") return "Hyprland"
        if (id === "arch") return "Arch"
        if (id === "omacom") return "Omacom"
        if (id === "grid") return "Grid"
        if (id === "spark") return "Spark"
        if (id === "power") return "Power"
        if (id === "dragon") return "Dragon"
        if (id === "mark") return "Mark"
        if (id === "nix") return "Nix"
        if (id === "branch") return "Branch"
        if (id === "rebel") return "Rebel"
        return "Omarchy"
    }
    function launcherLogoIconGlyph(id) {
        if (id === "omarchy") return String.fromCodePoint(0xE900)
        if (id === "hyprland") return ""
        if (id === "arch") return ""
        if (id === "grid") return ""
        if (id === "spark") return ""
        if (id === "power") return ""
        if (id === "dragon") return "⻯"
        if (id === "mark") return ""
        if (id === "nix") return ""
        if (id === "branch") return ""
        if (id === "rebel") return ""
        return String.fromCodePoint(0xE900)
    }
    function launcherLogoIconFont(id) {
        return id === "omarchy" ? "omarchy" : mono
    }
    function launcherLogoIconSize(id) {
        if (id === "omarchy") return 15
        if (id === "arch") return 17
        if (id === "dragon") return 16
        return 16
    }
    function launcherLogoIconXOffset(id) {
        if (id === "omarchy") return 0.5
        if (id === "hyprland") return 0
        if (id === "arch") return 1
        if (id === "grid") return -1
        if (id === "spark") return 0
        if (id === "power") return 0
        if (id === "dragon") return 0
        if (id === "mark") return 0.5
        if (id === "nix") return 0
        if (id === "branch") return 0
        return 0
    }
    function launcherLogoIconYOffset(id) {
        if (id === "omarchy") return 0
        if (id === "hyprland") return 0
        if (id === "arch") return 0
        if (id === "mark") return 0.5
        if (id === "branch") return 0
        if (id === "dragon") return 0
        return 0
    }

    Process {
        id: widgetLoadProc
        command: ["cat", theme.widgetsCachePath]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                var parts = this.text.trim().split(" ")
                if (parts.length >= 4) {
                    theme.modMemory    = parts[0] !== "0"
                    theme.modBrightness = parts[1] !== "0"
                    theme.modClaude    = parts[2] !== "0"
                    theme.modPower     = parts[3] !== "0"
                }
                // parts[4] is the bluetooth flag in the new format, but in the OLD
                // format it was the workspace mode ("10"/"5"/"active") — detect which.
                var wsField = -1
                if (parts.length >= 5) {
                    if (parts[4] === "5" || parts[4] === "active" || parts[4] === "10") {
                        wsField = 4                         // old format: no bluetooth field
                    } else {
                        theme.modBluetooth = parts[4] !== "0"
                        wsField = 5
                    }
                }
                if (wsField >= 0 && parts.length > wsField) {
                    var m = parts[wsField]
                    theme.workspaceMode = (m === "5" || m === "active") ? m : "10"
                    // pickerStyle is the field right after the workspace mode
                    if (parts.length > wsField + 1) {
                        var ps = parts[wsField + 1]
                        if (ps === "hearthstone" || ps === "carousel" || ps === "tanzaku")
                            theme.pickerStyle = ps
                    }
                    // weatherImperial / clock12h follow pickerStyle
                    if (parts.length > wsField + 2) theme.weatherImperial = parts[wsField + 2] === "1"
                    if (parts.length > wsField + 3) theme.clock12h        = parts[wsField + 3] === "1"
                    if (parts.length > wsField + 4) theme.modNetwork      = parts[wsField + 4] === "1"
                    // style tokens — appended after modNetwork, each guarded
                    if (parts.length > wsField + 5) theme.styleShadow      = parts[wsField + 5] === "1"
                    if (parts.length > wsField + 6) theme.styleRadiusSmall = parts[wsField + 6] === "1"
                    // field wsField+7 (styleHeightMin) is reserved for offset
                    // stability only — the Height toggle was removed (plan §1.4), so
                    // it is intentionally NOT parsed: a stray "1" must not shrink pills
                    // when there is no UI to undo it. (saveWidgets still writes "0".)
                    if (parts.length > wsField + 8) {
                        var wss = parts[wsField + 8]
                        if (wss === "numbers" || wss === "magic" || wss === "default")
                            theme.workspaceStyle = wss
                    }
                    if (parts.length > wsField + 9) {
                        var bp = parts[wsField + 9]
                        if (bp === "top" || bp === "bottom") theme.barPosition = bp
                    }
                    // +10 styleBorder (independent border on/off). Old caches lack it →
                    // migrate from the old coupled meaning: border = NOT shadow.
                    // Default-true → parse "!== 0" so a corrupted token keeps borders ON.
                    if (parts.length > wsField + 10) theme.styleBorder = parts[wsField + 10] !== "0"
                    else if (parts.length > wsField + 5) theme.styleBorder = !theme.styleShadow
                    // +11..+15 widget-group toggles (default ON → only an explicit "0"
                    // hides; old caches lack these fields → groups stay visible)
                    if (parts.length > wsField + 11) theme.modStatus = parts[wsField + 11] !== "0"
                    if (parts.length > wsField + 12) theme.modQuick  = parts[wsField + 12] !== "0"
                    if (parts.length > wsField + 13) theme.modCpu    = parts[wsField + 13] !== "0"
                    if (parts.length > wsField + 14) theme.modVolume = parts[wsField + 14] !== "0"
                    if (parts.length > wsField + 15) theme.modMpris  = parts[wsField + 15] !== "0"
                    if (parts.length > wsField + 16) {
                        var at = parts[wsField + 16]
                        if (at === "claude" || at === "codex" || at === "opencode") theme.aiTool = at
                    }
                    if (parts.length > wsField + 17) theme.styleFrost = parts[wsField + 17] === "1"
                    if (parts.length > wsField + 18) {
                        var lm = parts[wsField + 18]
                        if (lm === "text" || lm === "icon") {
                            theme.launcherLogoMode = lm
                            if (parts.length > wsField + 19 && theme.launcherLogoTextValid(parts[wsField + 19]))
                                theme.launcherLogoText = parts[wsField + 19]
                            if (parts.length > wsField + 20 && theme.launcherLogoIconValid(parts[wsField + 20]))
                                theme.launcherLogoIcon = parts[wsField + 20]
                        } else if (lm === "omarchy" || lm === "hyprland") {
                            // Legacy cache field from the first text-logo picker.
                            theme.launcherLogoMode = "text"
                            theme.launcherLogoText = lm
                        }
                    }
                    if (parts.length > wsField + 21) theme.archBadgePackages = parts[wsField + 21] !== "0"
                    if (parts.length > wsField + 22) theme.archBadgeThemes   = parts[wsField + 22] !== "0"
                    if (parts.length > wsField + 23) theme.compactNetwork    = parts[wsField + 23] === "1"
                    if (parts.length > wsField + 24) theme.compactBattery    = parts[wsField + 24] === "1"
                    if (parts.length > wsField + 25) theme.compactBrightness = parts[wsField + 25] === "1"
                    if (parts.length > wsField + 26) theme.compactCpu        = parts[wsField + 26] === "1"
                    if (parts.length > wsField + 27) theme.compactMemory     = parts[wsField + 27] === "1"
                    if (parts.length > wsField + 28) theme.compactVolume     = parts[wsField + 28] === "1"
                    if (parts.length > wsField + 29) theme.compactBluetooth  = parts[wsField + 29] === "1"
                    if (parts.length > wsField + 30) theme.compactPower      = parts[wsField + 30] === "1"
                    if (parts.length > wsField + 31) theme.archBadgeShell    = parts[wsField + 31] !== "0"
                    if (parts.length > wsField + 32) theme.compactMpris      = parts[wsField + 32] === "1"
                    if (parts.length > wsField + 33) theme.modSystemStats    = parts[wsField + 33] !== "0"
                    if (parts.length > wsField + 34) theme.modRadioAtlas     = parts[wsField + 34] !== "0"
                    if (parts.length > wsField + 35) theme.modBtcPrice       = parts[wsField + 35] !== "0"
                    if (parts.length > wsField + 36) {
                        var cfi = parseInt(parts[wsField + 36], 10)
                        if (!isNaN(cfi) && cfi >= 0 && cfi < theme.clockFormatRing.length) theme.clockFormatIndex = cfi
                    }
                }
                theme._widgetsLoaded = true
            }
        }
    }

    Process { id: widgetSaveProc }

    // ── New widget panel states ──
    property bool networkVisible:   false
    onNetworkVisibleChanged: popupOpened("networkVisible")
    property bool bluetoothVisible: false
    onBluetoothVisibleChanged: popupOpened("bluetoothVisible")
    property bool batteryVisible:   false
    onBatteryVisibleChanged: popupOpened("batteryVisible")
    property bool brightnessVisible: false
    onBrightnessVisibleChanged: popupOpened("brightnessVisible")
    property bool mprisVisible:     false
    onMprisVisibleChanged: popupOpened("mprisVisible")
    property bool weatherVisible:   false
    onWeatherVisibleChanged: popupOpened("weatherVisible")
    property bool workspaceVisible: false
    onWorkspaceVisibleChanged: popupOpened("workspaceVisible")

    // ── Image picker state (theme/wallpaper carousel) ──
    property bool   imagePickerVisible:  false
    onImagePickerVisibleChanged: popupOpened("imagePickerVisible")
    property string imagePickerMode:     "wallpaper"   // "theme" or "wallpaper"
    property real   quickActionsBarX:    0
    // ── Media browser state (screenshots/videos carousel) ──
    property bool   mediaBrowserVisible: false
    onMediaBrowserVisibleChanged: popupOpened("mediaBrowserVisible")
    property string mediaBrowserMode:    "screenshots"  // "screenshots" or "videos"
    // ── Idle inhibitor (Wayland idle-inhibit protocol) ──
    property bool   idleInhibited:       false
    // ── Notification state ──
    property bool notifVisible: false
    onNotifVisibleChanged: popupOpened("notifVisible")
    property int  notifCount:   0
    property real notifBarX:    0

    // ── Power Profile state ──
    property bool powerProfileVisible: false
    onPowerProfileVisibleChanged: popupOpened("powerProfileVisible")
    property string powerProfileCurrent: ""

    Process {
        id: initPowerProfile
        command: ["bash", "-c", "powerprofilesctl get 2>/dev/null || echo balanced"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                var p = this.text.trim()
                if (p) theme.powerProfileCurrent = p
            }
        }
    }

    // ── Hyprland workspace dispatch (config-mode-aware) ──
    // Hyprland 0.55 added Lua configs but still supports classic hyprlang, and
    // BOTH ship the same version number — so the dispatch form depends on which
    // config is ACTIVE, not the version: classic wants "workspace N", Lua wants
    // hl.dsp.focus({ workspace = N }). Probe the mode once with a harmless token:
    // "hl.dsp" alone yields the Lua error "hl.dispatch: expected a dispatcher"
    // under Lua, or "Invalid dispatcher" under classic — neither switches.
    property bool hyprUsesLua: false
    Process {
        id: hyprDispatchProbe
        command: ["bash", "-c", "hyprctl dispatch 'hl.dsp' 2>&1 | grep -qi 'hl\\.dispatch' && echo lua || echo classic"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: { theme.hyprUsesLua = (this.text.trim() === "lua") }
        }
    }
    function gotoWorkspace(id) {
        if (hyprUsesLua)
            Hyprland.dispatch("hl.dsp.focus({ workspace = " + id + " })")
        else
            Hyprland.dispatch("workspace " + id)
    }

    // ── Arch Updater state ──
    property bool archVisible: false
    onArchVisibleChanged: popupOpened("archVisible")
    property var archUpdates: []
    property int archRefreshTick: 0
    property string archScanId: ""
    property int archScanCheckedEpoch: 0
    property string archScanHash: ""
    property int archScanSystemCount: 0
    readonly property int archScanMaxAge: 900

    // ── Arch security gate (pre-install verdict per package) ──
    // idle | scanning | clean | warn | blocked | degraded
    property string archGateState: "idle"
    property var    archGateResults: []   // [{pkg,repo,old,new,verdict,reason}]
    property int    archGateOk: 0
    property int    archGateWarn: 0
    property int    archGateFail: 0
    property int    archGateBlacklist: 0
    property bool   archGateDegraded: false
    property string archGateListDate: ""   // freshest blacklist date (meta updated_at, else mtime)
    property bool   archGateStale: false          // protection list older than the gate's stale window
    property bool   archGateMirrorsAgree: false   // both feed mirrors produced an identical list
    property bool   archGateMirrorMismatch: false // feeds diverged → using their union, flagged

    // Manual retry, e.g. on panel open: a degraded verdict can be a transient
    // (blacklist file mid-update at scan time) and must not stick until the
    // next refresh.
    function archGateRescan() { archGate.rerun() }

    Process {
        id: archGate
        // Hang on the DATA, not the refresh trigger: archRefreshTick fires the
        // refresh, but archUpdates is only filled when the refresh finishes — so
        // watching the tick would scan the PREVIOUS list. Watch archUpdates.
        property var watched: theme.archUpdates
        onWatchedChanged: rerun()
        // A rerun restarts even a live scan (running=false→true). That kill makes
        // onExited see a nonzero (terminated) exit; flag it so onExited does NOT
        // mistake the deliberate kill for a crash and force degraded — that false
        // degraded could land AFTER a clean scan and stick ("protection limited" +
        // no "mirrors ✓" despite a healthy feed).
        property bool killing: false
        function rerun() {
            if (running) killing = true
            running = false   // restart even if a previous scan is still running
            theme.archGateResults = []
            theme.archGateOk = 0; theme.archGateWarn = 0; theme.archGateFail = 0
            theme.archGateBlacklist = 0; theme.archGateDegraded = false
            theme.archGateStale = false; theme.archGateMirrorsAgree = false; theme.archGateMirrorMismatch = false
            // Run the gate even with 0 updates — it still emits the meta line, so the
            // panel can always show the blacklist size / protection status.
            theme.archGateState = (theme.archUpdates && theme.archUpdates.length > 0)
                ? "scanning" : "clean"
            stdinEnabled = true   // re-arm stdin each run — onStarted sets it false to send EOF; without this the 2nd+ run reads disabled stdin and hangs in 'scanning'
            running = true
        }
        command: ["bash", Quickshell.env("HOME") + "/.local/bin/qs-arch-security-gate.sh"]
        stdinEnabled: true
        onStarted: {
            // Feed "pkg|repo|old|new" — exactly the gate's stdin format.
            var ups = theme.archUpdates || []
            for (var i = 0; i < ups.length; i++) {
                var u = ups[i]
                var repo = (u.source === "aur") ? "aur" : "system"
                write(u.name + "|" + repo + "|" + (u.oldVer || "") + "|" + (u.newVer || "") + "\n")
            }
            stdinEnabled = false   // EOF → gate finishes
        }
        stdout: StdioCollector {
            onStreamFinished: {
                var results = [], ok = 0, warn = 0, fail = 0, sawMeta = false
                var lines = this.text.trim().split("\n")
                for (var i = 0; i < lines.length; i++) {
                    var s = lines[i].trim(); if (!s) continue
                    var o; try { o = JSON.parse(s) } catch (e) { continue }
                    if (o.meta === "gate") {
                        sawMeta = true
                        theme.archGateBlacklist = o.blacklist || 0
                        if (o.degraded) theme.archGateDegraded = true
                        if (o.list_date) theme.archGateListDate = o.list_date
                        if (o.stale) theme.archGateStale = true
                        theme.archGateMirrorsAgree = (o.mirrors_agree === true)
                        theme.archGateMirrorMismatch = (o.mirror_mismatch === true)
                        continue
                    }
                    results.push(o)
                    if (o.verdict === "FAIL") fail++
                    else if (o.verdict === "WARN") warn++
                    else ok++
                }
                theme.archGateResults = results
                theme.archGateOk = ok; theme.archGateWarn = warn; theme.archGateFail = fail
                // Fail-CLOSED: if the gate didn't fully respond (no meta line, or a
                // package has no verdict — gate missing/crashed/partial), do NOT
                // claim "clean". An empty/short answer means "unverified", not "safe".
                if (!sawMeta || results.length !== (theme.archUpdates || []).length)
                    theme.archGateDegraded = true
                theme.archGateState =
                    fail > 0 ? "blocked"
                    : theme.archGateDegraded ? "degraded"
                    : warn > 0 ? "warn" : "clean"
            }
        }
        onExited: (exitCode) => {
            if (killing) { killing = false; return }   // we restarted it on purpose, not a crash
            // Gate exited nonzero (missing script, crash) => force degraded so the
            // panel never shows a false all-clear.
            if (exitCode !== 0) {
                theme.archGateDegraded = true
                if (theme.archGateFail === 0 && theme.archGateWarn === 0)
                    theme.archGateState = "degraded"
            }
        }
    }

    // ── Shell Updater state (shared by ArchUpdaterWidget and ShellUpdateTab) ──
    property int  shellUpdateBehind: 0
    property var  shellUpdateSummary: []
    property string shellUpdateVersion: ""
    property string shellUpdateChecked: ""
    property string shellUpdateBaseCommit: ""
    property string shellUpdateTargetCommit: ""
    property string shellUpdateRepository: ""
    property string shellUpdateUpstreamRef: ""
    property string shellInstalledCommit: ""
    property bool shellUpdateChecking: false
    property string shellProgressRunId: ""
    property string shellProgressState: "idle"
    property string shellProgressPhase: ""
    property int shellProgressStep: 0
    property int shellProgressTotalSteps: 5
    property string shellProgressTargetCommit: ""
    property int shellProgressStartedEpoch: 0
    property int shellProgressUpdatedEpoch: 0
    property string shellProgressScreenName: ""
    property string shellProgressError: ""
    property bool shellProgressAcknowledged: true
    property bool shellProgressPanelOpen: true
    property int shellProgressNowEpoch: Math.floor(Date.now() / 1000)
    property string _shellProgressCompleteRunId: ""
    readonly property bool shellProgressInterrupted: shellProgressState === "running"
        && shellProgressUpdatedEpoch > 0
        && shellProgressNowEpoch - shellProgressUpdatedEpoch > 600
    readonly property bool shellProgressRunning: shellProgressState === "running" && !shellProgressInterrupted
    readonly property bool shellProgressFailed: shellProgressState === "failed"
    readonly property bool shellProgressCompleted: shellProgressState === "completed" && !shellProgressAcknowledged
    readonly property bool shellUpdateProgressVisible: shellProgressRunning
        || shellProgressFailed || shellProgressCompleted || shellProgressInterrupted

    function updateShellProgressClock() {
        shellProgressNowEpoch = Math.floor(Date.now() / 1000)
    }

    function resetShellProgress() {
        shellProgressRunId = ""
        shellProgressState = "idle"
        shellProgressPhase = ""
        shellProgressStep = 0
        shellProgressTotalSteps = 5
        shellProgressTargetCommit = ""
        shellProgressStartedEpoch = 0
        shellProgressUpdatedEpoch = 0
        shellProgressScreenName = ""
        shellProgressError = ""
        shellProgressAcknowledged = true
        shellProgressPanelOpen = true
    }

    function openShellProgressPanel() {
        activatePopupScreenByName(shellProgressScreenName)
        activeUpdateTab = "shell"
        archVisible = true
    }

    function resetShellUpdateState() {
        shellUpdateBehind = 0
        shellUpdateSummary = []
        shellUpdateVersion = ""
        shellUpdateChecked = ""
        shellUpdateBaseCommit = ""
        shellUpdateTargetCommit = ""
        shellUpdateRepository = ""
        shellUpdateUpstreamRef = ""
    }

    function parseShellUpdateState(raw) {
        try {
            var j = JSON.parse(raw)
            if (j.schemaVersion !== 5) {
                resetShellUpdateState()
                return
            }
            shellUpdateBehind = j.behind || 0
            shellUpdateSummary = j.summary || []
            shellUpdateVersion = j.version || ""
            shellUpdateChecked = j.checked || ""
            shellUpdateBaseCommit = j.baseCommit || ""
            shellUpdateTargetCommit = j.targetCommit || ""
            shellUpdateRepository = j.repository || ""
            shellUpdateUpstreamRef = j.upstreamRef || ""
        } catch (e) {
            resetShellUpdateState()
        }
    }

    function parseShellInstalledCommit(raw) {
        shellInstalledCommit = raw.trim()
    }

    function parseShellProgress(raw) {
        try {
            var j = JSON.parse(raw)
            if (j.schemaVersion !== 1) {
                resetShellProgress()
                return
            }

            shellProgressRunId = j.runId || ""
            shellProgressState = j.state || "idle"
            shellProgressPhase = j.phase || ""
            shellProgressStep = j.step || 0
            shellProgressTotalSteps = j.totalSteps || 5
            shellProgressTargetCommit = j.targetCommit || ""
            shellProgressStartedEpoch = j.startedEpoch || 0
            shellProgressUpdatedEpoch = j.updatedEpoch || 0
            shellProgressScreenName = j.screenName || ""
            shellProgressError = j.error || ""
            shellProgressAcknowledged = j.acknowledged === true
            shellProgressPanelOpen = j.panelOpen !== false
            updateShellProgressClock()

            if (shellUpdateProgressVisible && shellProgressPanelOpen) openShellProgressPanel()
            if (shellProgressRunning
                    && shellProgressPhase === "restarting"
                    && shellProgressRunId !== ""
                    && _shellProgressCompleteRunId !== shellProgressRunId) {
                _shellProgressCompleteRunId = shellProgressRunId
                shellProgressCompleteProc.command = [
                    "bash",
                    Quickshell.env("HOME") + "/.config/quickshell/bin/qs-shell-apply-update.sh",
                    "--complete-progress",
                    shellProgressRunId
                ]
                shellProgressCompleteProc.running = false
                shellProgressCompleteProc.running = true
            }
        } catch (e) {
            resetShellProgress()
        }
    }

    function ackShellProgress() {
        if (!shellProgressRunId) return
        shellProgressAckProc.command = [
            "bash",
            Quickshell.env("HOME") + "/.config/quickshell/bin/qs-shell-apply-update.sh",
            "--ack-progress",
            shellProgressRunId
        ]
        shellProgressAckProc.running = false
        shellProgressAckProc.running = true
    }

    function setShellProgressPanelOpen(open) {
        if (!shellProgressRunId || !shellUpdateProgressVisible) return
        shellProgressPanelOpen = open
        shellProgressPanelProc.command = [
            "bash",
            Quickshell.env("HOME") + "/.config/quickshell/bin/qs-shell-apply-update.sh",
            "--progress-panel",
            shellProgressRunId,
            open ? "open" : "closed"
        ]
        shellProgressPanelProc.running = false
        shellProgressPanelProc.running = true
    }

    function closeArchUpdatesPanel() {
        if (shellUpdateProgressVisible) setShellProgressPanelOpen(false)
        archVisible = false
    }

    function showShellUpdateTabFromWidget() {
        if (shellUpdateProgressVisible) setShellProgressPanelOpen(true)
        activeUpdateTab = "shell"
        archVisible = true
    }

    function reloadShellUpdateState() {
        shellUpdateStateFile.reload()
        shellInstalledCommitFile.reload()
        shellProgressFile.reload()
    }

    Timer {
        interval: 15000
        running: shellProgressState === "running"
        repeat: true
        triggeredOnStart: true
        onTriggered: updateShellProgressClock()
    }

    FileView {
        id: shellUpdateStateFile
        path: Quickshell.env("HOME") + "/.cache/qs-shell/update-available.json"
        watchChanges: true
        printErrors: false
        onFileChanged: shellUpdateStateFile.reload()
        onLoaded: parseShellUpdateState(shellUpdateStateFile.text())
        onLoadFailed: resetShellUpdateState()
    }

    FileView {
        id: shellInstalledCommitFile
        path: Quickshell.env("HOME") + "/.config/quickshell/bar/.qsrise-commit"
        watchChanges: true
        printErrors: false
        onFileChanged: shellInstalledCommitFile.reload()
        onLoaded: parseShellInstalledCommit(shellInstalledCommitFile.text())
        onLoadFailed: shellInstalledCommit = ""
    }

    FileView {
        id: shellProgressFile
        path: Quickshell.env("HOME") + "/.cache/qs-shell/apply-status.json"
        watchChanges: true
        printErrors: false
        onFileChanged: shellProgressFile.reload()
        onLoaded: parseShellProgress(shellProgressFile.text())
        onLoadFailed: resetShellProgress()
    }

    Process {
        id: shellProgressCompleteProc
        command: ["true"]
        onExited: shellProgressFile.reload()
    }

    Process {
        id: shellProgressAckProc
        command: ["true"]
        onExited: {
            shellProgressFile.reload()
            archVisible = false
        }
    }

    Process {
        id: shellProgressPanelProc
        command: ["true"]
        onExited: shellProgressFile.reload()
    }

    // ── Theme Updater state (fed by ArchUpdaterPanel's FileView over
    //    ~/.cache/qs-theme-updates.json; the panel owns the check Process so it
    //    runs ONCE, not per-monitor). The bar/tooltip only read these counts;
    //    the panel renders themeUpdList. Theme updates run in a visible terminal
    //    through qs-theme-apply-update.sh and are pinned to the checked target
    //    commit. ──
    property int    themeUpdOutdated: 0
    property int    themeUpdLocalEdits: 0
    property int    themeUpdTotal: 0
    property int    themeUpdReachable: 0
    property bool   themeUpdDegraded: false
    property bool   themeUpdCurrentStale: false
    property string themeUpdChecked: ""      // ISO timestamp of the last check, "" = never
    property var    themeUpdList: []          // outdated/unreachable entries shown in the panel
    property bool   themeUpdChecking: false   // a check is in flight (button disabled)
    property int    themeCheckTick: 0         // ++ from the panel button to trigger a check
    property string activeUpdateTab: "packages"   // which ArchUpdaterPanel tab is shown
    property bool   archBadgePackages: true   // package count badge on the bar updater icon
    property bool   archBadgeThemes: true     // clean-theme count badge on the bar updater icon
    property bool   archBadgeShell: true      // shell-update badge on the bar updater icon

    // ── Tray state ──
    property bool trayVisible: false
    onTrayVisibleChanged: popupOpened("trayVisible")
    property var trayPinned: []
    property real trayBarX: 10

    // ── slot-aware panel X anchors (center-X of each group; set by BarSlot) ──
    property real volumeBarX:     0
    property real networkBarX:    0
    property real batteryBarX:    0
    property real memoryBarX:     0
    property real cpuBarX:        0
    property real systemStatsBarX: 0
    property real aiBarX:         0
    property real workspaceBarX:  0
    property real archBarX:       0
    property real bluetoothBarX:  0
    property real brightnessBarX: 0
    property real powerBarX:      0
    property real mprisBarX:      0
    property real weatherBarX:    0
    property real btcPriceBarX:   0
    property real launcherBarX:   6   // ControlPanel follows the Launcher/Control group

    // ── Tray context-menu state (themed menu, rendered by TrayMenu.qml) ──
    property bool trayMenuVisible: false
    onTrayMenuVisibleChanged: popupOpened("trayMenuVisible")
    property var  trayMenuHandle: null   // the QsMenuHandle of the clicked item
    property real trayMenuX: 0           // global x to anchor the menu under the icon
    property string trayMenuTitle: ""
    property string trayMenuIcon: ""

    function trayDisplayName(item) {
        if (!item) return "Tray App"

        var title = String(item.title || "").trim()
        if (title !== "") return title

        var tooltipTitle = String(item.tooltipTitle || "").trim()
        if (tooltipTitle !== "") return tooltipTitle

        var fallback = String(item.id || "").trim()
        var slash = fallback.lastIndexOf("/")
        if (slash >= 0 && slash < fallback.length - 1)
            fallback = fallback.substring(slash + 1)
        fallback = fallback.replace(/^org\.(kde|ayatana|freedesktop)\./i, "")
                           .replace(/[_-]+/g, " ")
        return fallback !== "" ? fallback : "Tray App"
    }

    function trayDescription(item, displayName) {
        if (!item) return ""

        var description = String(item.tooltipDescription || "").trim()
        var tooltipTitle = String(item.tooltipTitle || "").trim()
        var name = String(displayName || "").trim().toLowerCase()
        if (description !== "" && description.toLowerCase() !== name)
            return description
        if (tooltipTitle !== "" && tooltipTitle.toLowerCase() !== name)
            return tooltipTitle
        return ""
    }

    function openTrayMenu(handle, x, title, icon) {
        if (!handle) return
        trayMenuHandle = handle
        trayMenuTitle = String(title || "App Menu")
        trayMenuIcon = String(icon || "")
        setPanelAnchor("trayMenu", x)
        trayMenuVisible = true
    }

    function trayIsHidden(item) {
        return trayPinned.indexOf(item.id) < 0
    }

    // toggle: hidden items get pinned (shown in bar); pinned items get unpinned (back to panel)
    function trayToggleHide(item) {
        var key = item.id
        if (!key) return
        var i = trayPinned.indexOf(key)
        if (i >= 0) {
            var a = trayPinned.slice(0, i)
            var b = trayPinned.slice(i + 1)
            trayPinned = a.concat(b)
            trayVisible = false
        } else {
            trayPinned = trayPinned.concat([key])
        }
    }

    Process {
        id: omarchyCurrentRootProbe
        command: ["bash", "-c",
            "state=\"$HOME/.local/state/omarchy/current\"; legacy=\"$HOME/.config/omarchy/current\"; " +
            "if command -v omarchy-shell >/dev/null 2>&1 && [ -d \"$state\" ] && [ -d /usr/share/omarchy ]; then printf '%s\\t%s\\n' \"$state\" /usr/share/omarchy; " +
            "elif [ -d \"$legacy\" ]; then printf '%s\\t%s\\n' \"$legacy\" \"$HOME/.local/share/omarchy\"; " +
            "else printf '%s\\t%s\\n' \"$legacy\" \"$HOME/.local/share/omarchy\"; fi"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                var parts = this.text.trim().split("\t")
                var resolved = parts.length > 0 ? parts[0] : ""
                var installRoot = parts.length > 1 ? parts[1] : ""
                if (resolved) theme.omarchyCurrentRoot = resolved
                if (installRoot) theme.omarchyInstallRoot = installRoot
                theme.omarchyCurrentRootResolved = true
                currentThemeNameWatcher.reload()
                theme.reloadCurrentThemeFiles()
            }
        }
    }

    Timer {
        id: themeReloadDebounce
        interval: 40
        repeat: false
        onTriggered: {
            paletteReader.running = false
            paletteReader.running = true
        }
    }

    // Omarchy writes theme.name immediately after the complete theme directory
    // swap, before its slower application retint commands and final hooks.
    FileView {
        id: currentThemeNameWatcher
        path: theme.themeNamePath
        watchChanges: theme.omarchyCurrentRootResolved
        printErrors: false
        onLoaded: {
            theme.setCurrentThemeName(currentThemeNameWatcher.text())
            theme.reloadCurrentThemeFiles()
        }
        onLoadFailed: theme.setCurrentThemeName("")
        onFileChanged: {
            reload()
            theme.reloadCurrentThemeFiles()
        }
    }

    Process {
        id: paletteReader
        command: ["cat", theme.colorsPath]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                Palette.apply(theme, Palette.parse(this.text));
            }
        }
    }

    function ipcApplyTheme(payload) {
        let p;
        try { p = JSON.parse(payload); }
        catch (e) { console.warn("theme.apply: bad payload —", e); return; }
        if (!p || !p.colors) return;
        Palette.apply(theme, Palette.mapKeys(p.colors));
        theme.lastAppliedName = p.name || "";
    }

    function ipcApplyLauncher(payload) {
        let p;
        try { p = JSON.parse(payload); }
        catch (e) { console.warn("theme.applyLauncher: bad payload —", e); return; }
        theme.applyLauncherConfig(p);
    }

    function ipcReloadTheme() {
        paletteReader.running = false;
        paletteReader.running = true;
    }

    function ipcOpenPicker(mode) {
        if (mode === "theme" || mode === "wallpaper") openImagePicker(mode)
        else if (mode === "screenshots" || mode === "videos") openMediaBrowser(mode)
    }

    // Opens on the focused monitor, same as clicking the pill there.
    function ipcTogglePanel(name) {
        if (name !== "network") return
        var open = !networkVisible
        if (open) activateFocusedPopupScreen()
        networkVisible = open
    }

    // Standalone compatibility while the integrated bootstrap is being rolled
    // out. VariantRoot supplies variantHost, so only the common IPC router owns
    // these targets in integrated mode.
    LazyLoader {
        active: theme.variantHost === null
        IpcHandler {
            target: "theme"
            function apply(payload: string): void { theme.ipcApplyTheme(payload) }
            function applyLauncher(payload: string): void { theme.ipcApplyLauncher(payload) }
            function reload(): void { theme.ipcReloadTheme() }
        }
    }

    LazyLoader {
        active: theme.variantHost === null
        IpcHandler {
            target: "picker"
            function theme(): void { ipcOpenPicker("theme") }
            function wallpaper(): void { ipcOpenPicker("wallpaper") }
            function screenshots(): void { ipcOpenPicker("screenshots") }
            function videos(): void { ipcOpenPicker("videos") }
        }
    }
}
